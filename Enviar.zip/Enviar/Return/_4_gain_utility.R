# models = c("DNS","DNS-Macro","DNS-MacroE1","DNS-GARCH","DNS-GARCH-Macro","DNS-GARCH-MacroE1")
# cdim = read.csv("cdi1419.csv",head=TRUE,sep=";")[,2]
setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\Econ_Eval\\Experimento")

models = c("RW","DNS","DNS-Macro","DNS-GARCH","DNS-GARCH-Macro","DNS-TVL","DNS-TVL-Macro","DNS-GARCH-TVL","DNS-GARCH-TVL-Macro","DNSS","DNSS-GARCH","DNSS-TVL1","DNSS-TVL2","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2","DNSS-GARCH-TVL-Macro",
"DNS-GARCH-TVL-RW","DNS-RW-GARCH-Q-DIAG","DNS-RW-GARCH-TVL-RW","DNS-RW-GARCH-TVL-RW-Q-DIAG","DNS-Macro-RW","DNS-Macro-Q-Diag","DNS-Macro-RW-Q-Diag")

#---------------------------------#
# US Effective Federal Funds Rate #
#---------------------------------#

#library("fredr")
#fredr_set_key("c8532b9386011f4eeefc3f1c46150abc")

#init = as.Date("1994-02-01")
#fin = as.Date("2018-12-01")

#tmp = fredr(series_id = 'FEDFUNDS', observation_start = init, observation_end = fin)
#cdim = tmp$value # 299
#--

retobs_rf = readRDS("retobs_rf.rds")[,,264:564]
retobs = readRDS("retobs.rds")[,,264:564] # 301

dt = c(0.1,0.5,1,2,5,10)

for (w in 1:length(models)) {

	model = models[w]
	ret.prev = readRDS(paste0("rhat_",model,".rds"))
	sig.prev = abs(readRDS(paste0("sigmahat_",model,".rds")))
	
	nu.port = array(NA, c( dim(ret.prev)[1], dim(ret.prev)[2], length(dt) ) )

	for (i in 1:length(dt)) {
	
		wg0 = (1 / dt[i]) * (ret.prev / sig.prev)
		wg_rf = 1 - wg0

		tmp = array(NA, c( dim(wg0)[1], dim(wg0)[2], dim(wg0)[3] ) )

#		ret.port = (ret.obs - cdim) * wg0
		ret.port = retobs * wg0 + retobs_rf * wg_rf
		mu.port = apply(ret.port,c(1:2),mean)
		sig.port = apply(ret.port,c(1:2),var)
		nu.port[,,i] = mu.port - 0.5 * dt[i] * sig.port

	}
	saveRDS(wg0, file = paste0("wg-",model,".rds"))
	saveRDS(ret.port, file = paste0("ret.port-",model,".rds"))
	saveRDS(mu.port, file = paste0("mu.port-",model,".rds"))
	saveRDS(sig.port, file = paste0("sig2.port-",model,".rds"))
	saveRDS(nu.port, file = paste0("nu.port-",model,".rds"))
}

#------------------------#
# Diff between nu models #
#------------------------#

models = c("DNS","DNS-Macro","DNS-GARCH","DNS-GARCH-Macro","DNS-TVL","DNS-TVL-Macro","DNS-GARCH-TVL","DNS-GARCH-TVL-Macro","DNSS","DNSS-GARCH","DNSS-TVL1","DNSS-TVL2","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2","DNSS-GARCH-TVL-Macro",
"DNS-GARCH-TVL-RW","DNS-RW-GARCH-Q-DIAG","DNS-RW-GARCH-TVL-RW","DNS-RW-GARCH-TVL-RW-Q-DIAG","DNS-Macro-RW","DNS-Macro-Q-Diag","DNS-Macro-RW-Q-Diag")

base = readRDS("nu.port-RW.rds")

for(m in 1:length(models)){

	model = models[m]
	nudiff2 = matrix(NA,12,length(dt))
	nudiff = readRDS(paste0("nu.port-",model,".rds")) - base

	saveRDS(nudiff,file=paste0("nudiff-",model,"-BM.rds"))

}

ma = c(1,3,6,12)
table = array(NA,c((length(models)),length(c(1,12,24,36,48,60,72,84,96,108)),length(ma),length(dt)))

for(i in 1:length(dt)){

	for(j in 1:4){
		table[,,j,i] = rbind(
			readRDS(paste0("nudiff-",models[1],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i], # 1 = 1 ano, 12 = 2 anos, ...
			readRDS(paste0("nudiff-",models[2],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[3],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[4],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[5],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[6],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[7],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[8],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[9],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[10],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[11],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[12],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[13],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[14],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[15],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[16],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[17],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[18],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[19],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[20],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[21],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i],
			readRDS(paste0("nudiff-",models[22],"-BM.rds"))[ma[j],c(1,12,24,36,48,60,72,84,96,108),i]
		)

	}

}

gamma = 6

#write.csv(rbind(table[,,1,gamma],table[,,2,gamma],table[,,3,gamma],table[,,4,gamma]),file=paste0("gamma_",gamma,"_.csv"))
write.table(rbind(table[,,1,gamma],table[,,2,gamma],table[,,3,gamma],table[,,4,gamma]),file=paste0("gamma_",dt[gamma],"_.csv"),sep=";",dec = ",")

#c(1,12,24,36,48)
# 12,24,36,48,60
# 1, 2, 3, 4, 5


