suppressMessages(suppressWarnings(require(xts)))

# F: US Last
data = read.zoo("yields_long.zoo")
matu = c(rep(NA,length(colnames(data))))
for(i in 1:length(colnames(data))){
  matu[i] = as.numeric(gsub("X","",colnames(data)[i]))
}
Jan = dim(data[1:264,])[1] # in-sample: 1972:1 - 1993:12 = 264 observations


# BR: 2003-2019
# TOTAL = 192
# in-sample:  2003:08-2019:07 = 192 observations 
# out-of-sample: 2014:01-2019:07 = 66 observations

# data = read.zoo("https://www.dropbox.com/s/5l190lxmu766ohn/ybrm.zoo?dl=1")
# matu = c(1,3,6,9,12,15,18,21,24,27,30,33,36,39,48,60,72) # 17 maturities in the data;

# US 1970-2009
#data = read.zoo("https://www.dropbox.com/s/2wuy6jr51bhfygo/UnsmFB_70-09.zoo?dl=1")
#matu = c(rep(NA,length(colnames(data))))
#for(i in 1:length(colnames(data))){
#  matu[i] = as.numeric(gsub("M","",colnames(data)[i]))  
#}

# 5)*** US Diebold & Li (small)
# TOTAL = 203
# in-sample: 1985:1-1993:12 = 108 observations
# out-of-sample: 1994:1-2001:12 = 84 observations

#data = read.zoo("https://www.dropbox.com/s/2wuy6jr51bhfygo/UnsmFB_70-09.zoo?dl=1")
#matu = c(rep(NA,length(colnames(data))))
#for(i in 1:length(colnames(data))){
#  matu[i] = as.numeric(gsub("M","",colnames(data)[i]))  
#}
#Jan = dim(data[181:288,])[1] # in-sample: 1985:1-1993:12 = 108 observations
#data = data[181:384,] #-->[1:203,] out-of-sample: 1994:1-2001:12 

# 4) US (large)
# in-sample: 1985:1-2005:12 = 252 observations
# out-of-sample: 2006:1-2015:1 = 109 observations

#data = read.zoo("https://www.dropbox.com/s/zwi6am2lgnm8y1q/gurk_60_15.zoo?dl=1")
#matu = c(rep(NA,length(colnames(data))))
#for(i in 1:length(colnames(data))){
#  matu[i] = as.numeric(gsub("X","",colnames(data)[i]))  
#}
#data = data[285:536,] # in-sample: 1985:1-2005:12 observations
# data = data[537:645,] # out-of-sample: 2006:1-2015:1 = 109 observations [97 (X_star) + 12 (ahead)]

# 3_1)*** US (small)
# in-sample: 1972:1-1993:12 = 264 observations
# out-of-sample: 1994:1-2009:12 = 192 windows

#data = read.zoo("https://www.dropbox.com/s/2wuy6jr51bhfygo/UnsmFB_70-09.zoo?dl=1")
#matu = c(rep(NA,length(colnames(data))))
#for(i in 1:length(colnames(data))){
#  matu[i] = as.numeric(gsub("M","",colnames(data)[i]))  
#}
#Jan = dim(data[25:288,])[1] # in-sample: 1972:1-1993:12 = 264 observations
#data = data[25:480,] #-->[1:203,] out-of-sample: 1994:1-2009:12

# 2) US (large)
# in-sample: 1961:06 - 1985:12 =  observations
# out-of-sample: 1986:1 - 2000:12 =  observations

#data = read.zoo("https://www.dropbox.com/s/zwi6am2lgnm8y1q/gurk_60_15.zoo?dl=1")
#matu = c(rep(NA,length(colnames(data))))
#for(i in 1:length(colnames(data))){
#  matu[i] = as.numeric(gsub("X","",colnames(data)[i]))
#}
#data = data[1:296,] # in-sample: 1961:06 - 1985:12 = 296 observations
#data = data[1:476,] # out-of-sample: 1986:1 - 2000:12 = 180 (476-296) observations [ 168 (X_star) +  12 (ahead)]

# 1)*** US (large)
# in-sample:  =  observations
# out-of-sample:  =  observations

#data = read.zoo("https://www.dropbox.com/s/zwi6am2lgnm8y1q/gurk_60_15.zoo?dl=1")
#matu = c(rep(NA,length(colnames(data))))
#for(i in 1:length(colnames(data))){
#  matu[i] = as.numeric(gsub("X","",colnames(data)[i]))
#}
#Jan = dim(data[129:392,])[1] # in-sample: 1972:1 - 1993:12 = 264 observations
#data = data[129:645,] # out-of-sample: 1994:1 - 2015:1 = 253 (645-392) observations [ 241 (X_star) + 12(ahead)]

#-------#
# Teste #
#-------#
#DL original
#data = read.csv("https://www.dropbox.com/s/inpnlugzkddp42q/bonds.csv?dl=1",header = TRUE, sep = ";")#***
#require(xts)
#data = as.matrix(data[,which(names(data)=="M3"):which(names(data)=="M120")])
#datas = seq(as.Date("1972/1/1"), by = "month", length.out = 348)
#data = xts(data, order.by = datas)

#matu = c(rep(NA,length(colnames(data))))
#for(i in 1:length(colnames(data))){
#  matu[i] = as.numeric(gsub("M","",colnames(data)[i]))
#}
