#suppressMessages(suppressWarnings(require(xts)))
#data = read.zoo("https://www.dropbox.com/s/zwi6am2lgnm8y1q/gurk_60_15.zoo?dl=1")
#matu = c(rep(NA,length(colnames(data))))

# models = c("DNS","DNS-Macro","DNS-TVL","DNS-TVL-Macro","DNS-GARCH","DNS-GARCH-Macro","DNS-GARCH-TVL","DNS-GARCH-TVL-Macro","DNSS","DNSS-GARCH","DNSS-TVL1","DNSS-TVL2","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2")
# models = c("DNS-GARCH-Macro","DNSS-GARCH","DNS-GARCH-TVL","DNS-GARCH-TVL-Macro","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2")
# models = c("DNSS-TVL1","DNSS-TVL2","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2")
models = c("DNS-GARCH-TVL-RW","DNS-RW-GARCH-Q-DIAG","DNS-RW-GARCH-TVL-RW","DNS-RW-GARCH-TVL-RW-Q-DIAG",
			"DNS-Macro","DNS-Macro-Q-Diag","DNS-Macro-RW","DNS-Macro-RW-Q-Diag",
			"DNSS-GARCH-TVL-Macro", "DNS-GARCH-Macro", "DNS-GARCH-TVL-Macro","DNS-TVL-Macro")

#C:\Users\werle\Dropbox\paper_werley\paper_01\andre_portela\paper_werley\DNS-GARCH-TVL-RW
#C:\Users\werle\Dropbox\paper_werley\paper_01\andre_portela\paper_werley\DNS-RW-GARCH-Q-DIAG
#C:\Users\werle\Dropbox\paper_werley\paper_01\andre_portela\paper_werley\DNS-RW-GARCH-TVL-RW
#C:\Users\werle\Dropbox\paper_werley\paper_01\andre_portela\paper_werley\DNS-RW-GARCH-TVL-RW-Q-DIAG

#C:\Users\werle\Dropbox\paper_werley\paper_01\andre_portela\paper_werley\Testes\DNS-Macro

#C:\Users\werle\Dropbox\paper_werley\paper_01\andre_portela\paper_werley\DNS-Macro (In-Sample Only) -- RW está aqui

prev = TRUE
ahead = 12
lik = FALSE

# Jan = dim(data[129:392,])[1]
# data = data[129:645,]

#looping1 to run all models one by one. US_1972_2019
for(j in 5:length(models)){

	model = models[j]
	print(model)
	#if-else to set working directory
	if(model=="DNS-GARCH-TVL-RW"){ # 1
		setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\DNS-GARCH-TVL-RW")
		}else{
			if(model=="DNS-RW-GARCH-Q-DIAG"){ # 2
				setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\DNS-RW-GARCH-Q-DIAG")		
			}else{
				if(model=="DNS-RW-GARCH-TVL-RW"){ # 3
					setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\DNS-RW-GARCH-TVL-RW")
				}else{
					if(model=="DNS-RW-GARCH-TVL-RW-Q-DIAG"){ # 4
						setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\DNS-RW-GARCH-TVL-RW-Q-DIAG")
					}else{
						if(model=="DNSS-GARCH-TVL-Macro"||model=="DNS-GARCH-Macro"||model=="DNS-GARCH-TVL-Macro"||model=="DNS-TVL-Macro"){ # 5,6,7,8,9
							setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\DNS-Macro (In-Sample Only)")
						}else{
							if(model=="DNS-Macro"||model=="DNS-Macro-Q-Diag"||model=="DNS-Macro-RW"||model=="DNS-Macro-RW-Q-Diag"){ # 10,11,12
								setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\Testes\\DNS-Macro")
							}
						}
					}
				}
			}
		}

	parass = readRDS(paste0("parass_",model,".rds"))

	if(model=="DNS-Macro"||model=="DNS-Macro-Q-Diag"||model=="DNS-Macro-RW"||model=="DNS-Macro-RW-Q-Diag"||model=="DNSS-GARCH-TVL-Macro"||model=="DNS-GARCH-Macro"||model=="DNS-GARCH-TVL-Macro"||model=="DNS-TVL-Macro"){
		#setwd("DNS-Macro/US/US_1972_2019")
		source("Dados_Macro.R")
		X = Jan + ahead
	}else{
			source("dados.R")
			X = Jan + ahead 		
		}
	
	#if-else to set functions models
	if(model=="DNS-GARCH-TVL-RW"){ # 1
		mm = "dns-tvl-garch-rw"
		garch = TRUE
		}else{
			if(model=="DNS-RW-GARCH-Q-DIAG"){ # 2
			mm = "dns-garch-rw-q-diag"
			garch = TRUE
			}else{
				if(model=="DNS-RW-GARCH-TVL-RW"){ # 3
					mm = "dns-tvl-garch-rw"
					garch = TRUE
				}else{
					if(model=="DNS-RW-GARCH-TVL-RW-Q-DIAG"){ # 4
						mm = "dns-tvl-garch-rw"
						garch = TRUE
					}else{
						if(model=="DNS-Macro"){ # 5
							mm = "dns-baseline"
							garch = FALSE
						}else{
							if(model=="DNS-Macro-Q-Diag"){ # 6
								mm = "dns-baseline-q-diag"
								garch = FALSE
							}else{
								if(model=="DNS-Macro-RW"){ # 7
									mm = "dns-rw-baseline"
									garch = FALSE
								}else{
									if(model=="DNS-Macro-RW-Q-Diag"){ # 8
										mm = "dns-rw-baseline-q-diag"
										garch = FALSE
									}else{
										if(model=="DNSS-GARCH-TVL-Macro"){ # 9
											mm = "dnss-garch-tvl-macro"
											garch = TRUE
										}else{
											if(model=="DNS-GARCH-Macro"){ # 10
												mm = "dns-garch-macro"
												garch = TRUE
											}else{
												if(model=="DNS-GARCH-TVL-Macro"){ # 11
													mm = "dns-garch-tvl-macro"
													garch = TRUE
												}else{
													if(model=="DNS-TVL-Macro"){ # 12
														mm = "dns-tvl-macro"
														garch = FALSE												
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	source(paste0(mm,"-fun.R"))

	if(garch){
		Sigma = array(NA, c(12, 17, dim(parass)[1]))	
	}
	
	YF = array(NA, c(12, 17, dim(parass)[1]))

	#looping2 to run models and to save forecasts
	for(i in 1:dim(parass)[1]){

		para = parass[i,]
		data1 = data[i:(i+X-1),]

		#if(model=="DNSS-GARCH-TVL1"||model=="DNSS-GARCH-TVL2"){
		#	results = kalman(para = para, Y = data1, lik = lik, prev = prev, ahead = ahead,
		#                 matu = matu, model = model)
		#}else{
		#	results = kalman(para = para, Y = data1, lik = lik, prev = prev, ahead = ahead,
		#                 matu = matu)
		#}
		
		results = kalman(para = para, Y = data1, lik = lik, prev = prev, ahead = ahead, matu = matu)

		# Looping to get last volatility matrix
		if(garch){
			for(w in 1:12){

				if(w==1){
					tmp = diag(results$Sigma.yy[,,(dim(results$Sigma.yy)[3]-(12-w))])
				}else{
					if(w>1){
						tmp = rbind(tmp,diag(results$Sigma.yy[,,(dim(results$Sigma.yy)[3]-(12-w))]))	
					}

				}
			}
		}
		if(garch){
			Sigma[,,i] = tmp
		}

		YF[,,i] = results$Yf[(dim(results$Yf)[1]-11):dim(results$Yf)[1],]

		pb = txtProgressBar(min = (1/dim(parass)[1]), max = dim(parass)[1], style = 3)
		setTxtProgressBar(pb,i)
	
	} # end looping2

	# Save results
	setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\Econ_Eval")
	
	if(garch){
		saveRDS(Sigma,file=paste0("Sigma","_",model,".rds"))
	} 
	
	saveRDS(YF,file=paste0("YF","_",model,".rds")) 
	if(model=="DNS-Macro"||model=="DNS-Macro-Q-Diag"||model=="DNS-Macro-RW"||model=="DNS-Macro-RW-Q-Diag"){
		setwd("..")
		setwd("..")	
	}else{
		setwd("..")
	}
	
	
}# end looping1