# README: calculate rhat and sigmahat
setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\Econ_Eval\\Experimento")
source("dados.R")
data = readRDS("dataSp.rds")/100

models = c(
"DNS-GARCH-Macro","DNS-GARCH-TVL-Macro","DNS-GARCH-TVL-RW","DNS-GARCH-TVL","DNS-GARCH","DNS-RW-GARCH-Q-DIAG","DNS-RW-GARCH-TVL-RW-Q-DIAG","DNS-RW-GARCH-TVL-RW","DNSS-GARCH-TVL-Macro","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2","DNSS-GARCH",
"DNS-Macro-Q-Diag","DNS-Macro-RW-Q-Diag","DNS-Macro-RW","DNS-Macro","DNS-TVL-Macro","DNS-TVL","DNS","DNSS-TVL1","DNSS-TVL2","DNSS","RW")

matu_max <- 120
matu = 13:matu_max
ahead = 12
# X = Jan + ahead
X = Jan
retobs = readRDS("retobs.rds") # Não utilizado

for (k in 1:length(models)) {

	model = models[k]
	if(model=="DNS-GARCH-Macro"||model=="DNS-GARCH-TVL-Macro"||model=="DNS-GARCH-TVL-RW"||model=="DNS-GARCH-TVL"||model=="DNS-GARCH"||model=="DNS-RW-GARCH-Q-DIAG"||model=="DNS-RW-GARCH-TVL-RW-Q-DIAG"||model=="DNS-RW-GARCH-TVL-RW"||model=="DNSS-GARCH-TVL-Macro"||model=="DNSS-GARCH-TVL1"||model=="DNSS-GARCH-TVL2"||model=="DNSS-GARCH"){
	
		GARCH = TRUE
	
	}else{
	
		GARCH = FALSE
	
	}
	print( model )

	YF = readRDS(paste0("YFSp_",model,".rds"))/100 # modificado

	if(GARCH){

		Sigma = abs(readRDS(paste0("SigmaSp_",model,".rds")))/10000 # GARCH on # modificado
	
	}
	
	r = array(NA, c( dim(YF)[1], length(matu), dim(YF)[3] ) ) # modificado
	sig = array(NA, c( dim(YF)[1], length(matu), dim(YF)[3] ) ) # modificado

	for (w in 1:dim(YF)[3]) { 

		data1 = data[w:(w + X - 1),] 
		retobs1 = retobs[,,(w:(w + X - 1))] # Não utilizado...

		for (i in 1:ahead ) {

			for (j in 13:matu_max ){
		                           # t                                                t + 1                                                            # Ajuste contra livre de risco
				r[i,(j - 12),w] = ( (matu[j - 12]) / 12 * as.numeric(data1[Jan, j]) - ( (matu[j - 12]/12) - (i/12) ) * YF[i,(matu[j - 12] - i), w] ) # r_hat # modificado
				#r[i,j,w] = matu[j] * as.numeric(data1[Jan, j]) - ( matu[j] - ahead2[i] ) * YF[i, j, w] # r_hat										((1+(as.numeric(data[w,h])))^(h/12)-1)

				if(GARCH){
		
					# sig[i,(j - 12),w] = (matu[j - 12]/12)^2 * Sigma[i,(matu[j - 12] - i),w]
						sig[i,,w] = (matu[j - 12]/12)^2 * Sigma[i,(matu[j - 12] - i),w]
		
					}
			}
		}

		if(GARCH==FALSE){
		
			sig[,,w] = apply(retobs1,c(1:2),var) # GARCH off  # Não utilizado...
		
		}

		pb = txtProgressBar(min = (1/dim(YF)[3]), max = dim(YF)[3], style = 3)
		setTxtProgressBar(pb,w)

	}
	saveRDS(r,file=paste0("rhat_",model,".rds"))
	saveRDS(sig,file=paste0("sigmahat_",model,".rds"))
}
