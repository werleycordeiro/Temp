setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\Econ_Eval") 
source("dados.R")

# source("Dados_Macro.R") 

#-------------#
# Spline data #
#-------------#

t = matu
for(i in 1:nrow(data))
{
	y = as.numeric(data[i,])
	spl = smooth.spline(y ~ t)
	t.new = c(1:matu[17]) # ... mudar
	new = predict(spl, t.new)

	if(i==1){
		dataSp = new$y
	}else{
		dataSp = rbind(dataSp,new$y)
	}

}
colnames(dataSp)=t.new
saveRDS(dataSp,file="dataSp.rds")

#--------------#
# YF and Sigma #
#--------------#

models = c(
"DNS-GARCH-Macro",
"DNS-GARCH-TVL-Macro",
"DNS-GARCH-TVL-RW",
"DNS-GARCH-TVL",
"DNS-GARCH",
"DNS-RW-GARCH-Q-DIAG",
"DNS-RW-GARCH-TVL-RW-Q-DIAG",
"DNS-RW-GARCH-TVL-RW",
"DNSS-GARCH-TVL-Macro",
"DNSS-GARCH-TVL1",
"DNSS-GARCH-TVL2",
"DNSS-GARCH",
"DNS-Macro-Q-Diag",
"DNS-Macro-RW-Q-Diag",
"DNS-Macro-RW",
"DNS-Macro",
"DNS-TVL-Macro",
"DNS-TVL",
"DNS",
"DNSS-TVL1",
"DNSS-TVL2",
"DNSS",
"RW")


for(m in 1:length(models)){

	yf = readRDS(paste0("YF_",models[m],".rds")) # YF
	YFSp = array(NA, c( dim(yf)[1], matu[17], dim(yf)[3] ) )

	if(models[m]=="DNS-GARCH-Macro"||models[m]=="DNS-GARCH-TVL-Macro"||models[m]=="DNS-GARCH-TVL-RW"||models[m]=="DNS-GARCH-TVL"||models[m]=="DNS-GARCH"||models[m]=="DNS-RW-GARCH-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW"||models[m]=="DNSS-GARCH-TVL-Macro"||models[m]=="DNSS-GARCH-TVL1"||models[m]=="DNSS-GARCH-TVL2"||models[m]=="DNSS-GARCH"){
		sig = readRDS(paste0("Sigma_",models[m],".rds")) # Sigma
		SigmaSp = array(NA, c( dim(yf)[1], matu[17], dim(yf)[3] ) ) 
	}
	
	for(a in 1:dim(YFSp)[3]){

		tmp = yf[,,a]
		if(models[m]=="DNS-GARCH-Macro"||models[m]=="DNS-GARCH-TVL-Macro"||models[m]=="DNS-GARCH-TVL-RW"||models[m]=="DNS-GARCH-TVL"||models[m]=="DNS-GARCH"||models[m]=="DNS-RW-GARCH-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW"||models[m]=="DNSS-GARCH-TVL-Macro"||models[m]=="DNSS-GARCH-TVL1"||models[m]=="DNSS-GARCH-TVL2"||models[m]=="DNSS-GARCH"){ 
			tmp2 = sig[,,a]
		}
		
		for(i in 1:nrow(tmp)){

			y = as.numeric(tmp[i,])
			spl = smooth.spline(y ~ t)
			t.new = c(1:matu[17])
			new = predict(spl, t.new)
			YFSp[i,,a] = new$y

			if(models[m]=="DNS-GARCH-Macro"||models[m]=="DNS-GARCH-TVL-Macro"||models[m]=="DNS-GARCH-TVL-RW"||models[m]=="DNS-GARCH-TVL"||models[m]=="DNS-GARCH"||models[m]=="DNS-RW-GARCH-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW"||models[m]=="DNSS-GARCH-TVL-Macro"||models[m]=="DNSS-GARCH-TVL1"||models[m]=="DNSS-GARCH-TVL2"||models[m]=="DNSS-GARCH")
			{
			y = as.numeric(tmp2[i,])
			spl = smooth.spline(y ~ t)
			t.new = c(1:matu[17])
			new = predict(spl, t.new)
			SigmaSp[i,,a] = new$y
		}
			
		}

	}

	saveRDS(YFSp,file=paste0("YFSp_",models[m],".rds"))
	if(models[m]=="DNS-GARCH-Macro"||models[m]=="DNS-GARCH-TVL-Macro"||models[m]=="DNS-GARCH-TVL-RW"||models[m]=="DNS-GARCH-TVL"||models[m]=="DNS-GARCH"||models[m]=="DNS-RW-GARCH-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW-Q-DIAG"||models[m]=="DNS-RW-GARCH-TVL-RW"||models[m]=="DNSS-GARCH-TVL-Macro"||models[m]=="DNSS-GARCH-TVL1"||models[m]=="DNSS-GARCH-TVL2"||models[m]=="DNSS-GARCH"){
		saveRDS(SigmaSp,file=paste0("SigmaSp_",models[m],".rds"))
	}
}
