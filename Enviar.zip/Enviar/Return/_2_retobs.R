setwd("C:\\Users\\werle\\Dropbox\\paper_werley\\paper_01\\andre_portela\\paper_werley\\Econ_Eval\\Experimento")

data = readRDS("dataSp.rds")/100
matu_max = 120
matu = c(13:matu_max)
ahead = 12
rol = nrow(data) - ahead
retobs = array(NA, c( ahead, length(matu), rol ) )
retobs_rf = array(NA, c( ahead, length(matu), rol ) )

for(w in 1:rol){

	for(h in 1:ahead){

		for(i in 13:matu_max){
                                 # t                                         t + 1                                                                     # Ajuste contra livre de risco   
			retobs_rf[h,(i-12),w] = as.numeric(data[w,h])
			retobs[h,(i-12),w] = ( (matu[i-12])/12 * as.numeric(data[w,i]) - ((matu[i-12])/12 - (h/12)) * as.numeric(data[(w + h),(matu[i-12] - h)]) )	
		}

		pb = txtProgressBar(min = (1/rol), max = rol, style = 3)
		setTxtProgressBar(pb,w)

	}
}

saveRDS(retobs_rf,file="retobs_rf.rds")
saveRDS(retobs,file="retobs.rds")


#==================================================================================================================================
# Calcular retorno de um título qualquer
# em t, esse título tem maturidade X 
# em t+1, esse título tem maturidade X-1 
# Portanto, o retorno desse título é calculado entre t e t+1 de título com maturidade X e X-1, respectivamente.
# Generalizando, o retorno de um título entre t e t+h deve ser caculado entre títulos com maturidades X e X-h.
# No nosso estudo, podemos pegar retornos observados de 1, 3, 6 e 12 meses
# Sendo assim, vamos precisar pegar as 12 primeiras observações e 12 primeiras maturidades para montar essa estrutura de retornos
# O retorno observado vai até 12/2020
#=================================================================================================================================== 

# Retorno de 1 mês (começa na Maturidade de 2M)

# t
tau1 = 2/12
int1 = (data[1,2]/100)

# t + 1
tau2 = 1/12
int2 = (data[2,1]/100)

(exp(-int2*tau2)/exp(-int1*tau1)-1)*100

# Retorno de 6 mês (começa na Maturidade de 7M)

# t
tau1 = 6/12
int1 = (data[1,7]/100)

# t + 1
tau2 = 1/12
int2 = (data[7,1]/100)

(exp(-int2*tau2)/exp(-int1*tau1)-1)*100

# Retorno de 12 mês (começa na Maturidade de 13M)

# Exemplo
# t
tau1 = 12/12
int1 = (data[1,13]/100)

# t + 1
tau2 = 1/12
int2 = (data[13,1]/100)


# Recursão
i = 1 # Até 204
j = 13 # Até 60

retobs_v2 = matrix(NA,204,48)

for(i in 1:204){

	for(j in 13:60){

		# t1
		tau1 = (j-1)/12
		int1 = (data[i,j]/100)

		# t2
		tau2 = (j-12)/12
		int2 = (data[(i+12),(j-12)]/100)

		retobs_v2[i,(j-12)] <- ((exp(-int2*tau2)/exp(-int1*tau1))-1)*100

	}

}









