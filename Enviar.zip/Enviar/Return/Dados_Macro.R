#----------#
# Dados BR #
#----------#
suppressMessages(suppressWarnings(require(xts)))

#data = read.zoo("yieldsWCC.zoo")
#matu = c(rep(NA,dim(data)[2]))
#for(i in 1:dim(data)[2]){
#  matu[i] = as.numeric(gsub("X","",colnames(data)[i]))  
#}
#data = data[-(1:7),]
#rm(i)

#Jan = dim(data[1:120,])[1] # in-sample: 2003:1 - 2012:12 = 120 observations
# data = data # out-of-sample: 2013:1 - 2019:12 = 83 (645-392) observations [ 241 (X_star) + 12(ahead)]

#----------#
# Macro BR #
#----------#

#selic = as.numeric(read.csv("SelicR.csv",header=FALSE,sep=";")[,2]) # Realizada
#ipca = as.numeric(read.csv("IPCAA.csv",header=FALSE,sep=";")[,2]) # Acumulado anual
#ibc = as.numeric(read.csv("ibcbrAS.csv",header=FALSE,sep=";")[,2]) # base 100 = dez/2002
#macro = cbind(ibc,selic,ipca)

#-------------#
# Macro BR E1 #
#-------------#

#eselic = as.numeric(read.csv("E_Selic.csv",header=FALSE,sep=";")[,2]) # Realizada
#eipca = as.numeric(read.csv("E_IPCA.csv",header=FALSE,sep=";")[,2]) # Acumulado anual
#epib = as.numeric(read.csv("E_PIB.csv",header=FALSE,sep=";")[,2]) # base 100=dez/2002
#macro = cbind(epib,eselic,eipca)

# Prepare dataset to two-step estimation. Come from 'parti.R' (18,18,18,19)
#1)1:120
#2)19:138
#3)37:156
#4)55:174
#data = data[55:174,]
#eselic = as.numeric(read.csv("E_Selic.csv",header=FALSE,sep=";")[,2]) 
#eipca = as.numeric(read.csv("E_IPCA.csv",header=FALSE,sep=";")[,2]) 
#epib = as.numeric(read.csv("E_PIB.csv",header=FALSE,sep=";")[,2]) 
#macro = cbind(epib,eselic,eipca)

#----------#
# Dados US #
#----------#

#suppressMessages(suppressWarnings(require(xts)))

# 1)*** US (large)

#----------#
# US Last  #
#----------#

data = read.zoo("yields_long.zoo")
matu = c(rep(NA,length(colnames(data))))
for(i in 1:length(colnames(data))){
  matu[i] = as.numeric(gsub("X","",colnames(data)[i]))
}
Jan = dim(data[1:264,])[1] # in-sample: 1972:1 - 1993:12 = 264 observations
rm(i)

# Prepare dataset to two-step estimation. Come from 'parti.R'
#1)1:264
#2)76:339
#3)151:414
#4)227:489

## data = data[227:489,]
##cu = read.csv(file="CU2.csv",header=FALSE,sep=";")[227:489,2]
##ffr = read.csv(file="FFR2.csv",header=FALSE,sep=";")[227:489,2]
##infl = read.csv(file="PCE2.csv",header=FALSE,sep=";")[227:489,2]

macro = read.csv('data_macro.csv',header=T)[,-1]
macro = apply(macro,2,as.numeric)
