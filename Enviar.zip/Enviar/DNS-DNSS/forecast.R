# Author: Werley Cordeiro
# werleycordeiro@gmail.com
#----------#
# Previsão #
#----------#
source("dados.R")
ahead = 12
#----------#
# Partição #
#----------#
choices_model = c("DNS","DNSS")
model = select.list(choices_model,graphics = FALSE)
choices_part = c("P1","P2","P3","P4")
P = select.list(choices_part,graphics = FALSE)

forecast = function(model,P,Jan,data,ahead,matu){ ## 01
#266= 264 + 12 Ex.
  X = Jan + ahead # Qtd. de obs que entra para previsão; Dentro da função "...-fun.R" são cortadas as 'aheads' últimas; ## 02
  rol = dim(data)[1] - X + 1 # Qtd. de rolagens que são feitas até fim (menos ahead) da amostra out-of-sample; ## 03
  source("parti.R") 
  parti = part(rol) # dividir as rolagens em 4 partições para diminuir tempo computacional total das previsões; ## 04

if(P=="P1"){ # P1:[1:(X+1),] até [22:(X+22),]  # 22 janelas 
      a = 0 
      rol_part = parti$P1 ## 05
    }else{
      if(P=="P2"){ # P2:[23:(X+23),] até [44:(X+44),] #22 janelas 
          a = parti$P1 
          rol_part = parti$P2 ## 06
      }else{
          if(P=="P3"){ # P3:[45:(X+45),] até [66:(X+66),] #22 janelas 
          a = parti$P1 + parti$P2 
            rol_part = parti$P3 ## 07
        }else{
          if(P=="P4"){ # P4:[67:(X+67),] até [88:(X+88),] #22 janelas.
              a = parti$P1 + parti$P2 + parti$P3 
                rol_part = parti$P4 ## 08
            }
          }
      }
  }

if(model=="DNS"){
    source("dns-baseline-fun.R")
      source("bounds-dns-baseline.R")
      parasX = matrix(NA,rol_part,36) # change number of parameters according to the model ## 09
  }else{
      if(model=="DNSS"){
      source("dnss-baseline-fun.R")
      source("bounds-dnss-baseline.R")
      parasX = matrix(NA,rol_part,49) # change number of parameters according to the model ## 10
      }
  } 
 
  paras = readRDS(paste0("parass_",model,"-TS.rds")) # --------------- 
  NN = dim(paras)[2] # --------------- 

 	vero = matrix(0,rol_part,1) ## 011
 	mse = array(NA,c(ahead,length(matu),rol_part)) ## 012
 	colnames(mse) = c(paste0("M",matu))
 	rownames(mse) = c("1 month",paste0(c(2:ahead)," months"))
 	
  for(j in 1:rol_part){ ## 013

      para = paras[j+a,] # there was a mistake here: missed '+a' # --------------- 
      data2 = data[(j+a):(j+X+a-1),] # o número em "a" indica a partição que estamos; "-1" pq temos que "tirar" o contador j da soma; ## 014
  		lik = TRUE
  		prev = TRUE # corta as 'aheads' últimas observações do data2
      
      otim = nlminb(para, kalman, Y = data2, lik = lik, prev = prev,ahead = ahead, 
         	matu = matu,control = list(trace=1))
    	
    	lik = FALSE
    	prev = TRUE
    	results = kalman(para = otim$par,Y = data2,lik = lik,prev = prev, ahead = ahead,matu = matu)
    	
      if ( !is.null(dim(results$Yf)) ) {
      zz = results$Yf[(Jan+1):(Jan+ahead),] - data2[(Jan+1):(Jan+ahead),]
      } else {
      results = kalman(para = para, Y = data2, lik = lik, prev = prev, ahead = ahead, matu = matu)
      zz = results$Yf[(Jan+1):(Jan+ahead),] - data2[(Jan+1):(Jan+ahead),]
      }
      
      # Check 1 # <-------

    	t1 = mean(zz^2)

    	if(t1>=1 || is.na(t1) || is.nan(t1)){ ## 018
        lik = TRUE
  			prev = TRUE
  		
        otim = optim(para,kalman,Y = data2,lik = lik,prev = prev,ahead = ahead,matu = matu,
  				control = list(trace=1,maxit=1500),method = c("Nelder-Mead"),hessian = FALSE)

  			vero[j,] = otim$value
  			parasX[j,] = otim$par
  			lik = FALSE
  			prev = TRUE
  			results = kalman(para = otim$par,Y = data2,lik = lik,prev = prev,
  				ahead = ahead,matu = matu)

        if ( !is.null(dim(results$Yf)) ) {
        mse[,,j] = results$Yf[(Jan+1):(Jan+ahead),]-data2[(Jan+1):(Jan+ahead),]
         } else {
        results = kalman(para = para, Y = data2, lik = lik, prev = prev, ahead = ahead, matu = matu)
        mse[,,j] = results$Yf[(Jan+1):(Jan+ahead),]-data2[(Jan+1):(Jan+ahead),]
        }
      
  			message(paste0(" ### Finalizado iteração & previsão ",model," ----> "),(a+j))

		    }else{

      		vero[j,] = otim$objective
      		parasX[j,] = otim$par
      		mse[,,j] = zz
      		message(paste0(" ### Finalizado iteração & previsão ",model," ----> "),(a+j))
    	 } # End if-else
  	 } # End for
	saveRDS(mse, file = paste0("mse_",P,"_",model,".rds")) # stuff to calculate Mean Squared Error
	saveRDS(parasX, file = paste0("paras_",P,"_",model,".rds")) # will be used in the next models as start parameters
	saveRDS(vero, file = paste0("veros_",P,"_",model,".rds")) # just check loglikelihood
} #End function

forecast(model = model,P = P,Jan = Jan,data = data,ahead = ahead,matu = matu)