# author: Werley Cordeiro
# werleycordeiro@gmail.com
models = c("DNS-baseline","DNSS-baseline")
model = select.list(models,graphics = FALSE)
otim_nlminb = function(model,para,Y,lik,prev,ahead,matu,lower,upper){
  if(model=="DNS-baseline"){
    source("dns-baseline-fun.R")
    low = rep(-Inf,36)
    up = rep(Inf,36)
    para = readRDS("para_DNS-TS.rds")
  }else{
    if(model=="DNSS-baseline"){
      source("dnss-baseline-fun.R")
      low = rep(-Inf,49)
      up = rep(Inf,49)
      para = readRDS("para_DNSS-TS.rds")
    }
  }
 otim = nlminb(para,kalman,Y = data,lik = lik,prev = prev,ahead = ahead,matu = matu,
  	control = list(trace=1),lower = low,upper = up)
 return(otim)
}
source("dados.R")
prev = FALSE # TRUE to Forecast.
ahead = 12 # X-step ahead forecast
lik = TRUE # TRUE to return the value of the loglikelihood function. FALSE to return parameters.
otim = otim_nlminb(model = model,para = para,Y = data,lik = lik,prev = prev,
	ahead = ahead,matu = matu,lower = low,upper = up)
return(otim)
if(model=="DNS-baseline"){
	saveRDS(otim$par,file="otim_DNS-baseline.rds")
}else{
	if(model=="DNSS-baseline"){
		saveRDS(otim$par,file="otim_DNSS-baseline.rds")
	}
}
