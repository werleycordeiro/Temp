kalman = function(para,Y,lik,prev,ahead,matu) {#***
  
  source("lyapunov.R")
  source("Nelson.Siegel.factor.loadings.R")
  source("Kfilter.R")
  source("Fchol.R")

  l = exp(para[1])
  M = ahead #***
  # Resize data if Forecast is on
  if(prev){#*** Forecast
    T = nrow(Y)
    Yf = Y
    Yf[(T-M+1):T,] = NA
    Y = Y[1:(T-M),]
    T = nrow(Y)
  }else{
    Yf = NA
    T = nrow(Y)
  }#***
  W = ncol(Y)
  N = 3
  

  #mu = matrix(0,N,1) 
  #phi = matrix(0,N,N)
  # H = diag(0,ncol(Y))
  Q = matrix(0,N,N)
  Z = Nelson.Siegel.factor.loadings(l,matu)

  #for(i in 1:17){
  #  H[i,i] = exp(para[1 + i])
  #}
  H = diag(para[2:18])
  H = H %*% H
  phi = matrix(para[19:27],N,N)
  mu = para[28:30]
  Q[lower.tri(Q, diag = TRUE)] = para[31:36]
  Q = Q %*% t(Q)

  #phi[1,1] = para[19]
  #phi[1,2] = para[20]
  #phi[1,3] = para[21]
  #phi[2,1] = para[22]
  #phi[2,2] = para[23]
  #phi[2,3] = para[24]
  #phi[3,1] = para[25]
  #phi[3,2] = para[26]
  #phi[3,3] = para[27]
  # Mean vector
  #mu[1] = para[28]
  #mu[2] = para[29]
  #mu[3] = para[30]
  # Transition covariance matrix of residuals
  #Q[2,1] = para[32]
  #Q[3,1] = para[34]
  #Q[3,2] = para[35]
  #Q = Q + t(Q) 
  #Q[1,1] = exp(para[31])
  #Q[2,2] = exp(para[33])
  #Q[3,3] = exp(para[36])
  v1 = matrix(NA,T,W)			  
  v2 = matrix(NA,T,W) # Filtered errors: are defined as the difference between the observed yield curve and its filtered estimate from KF
  # Resize data if Forecast is on.
  if(prev){#*** 
    a.tt = matrix(NA, (T+M), N)
    a.t = matrix(NA, (T+M+1), N) # if prev=TRUE, always will be dim(a.t)[1]=348
    P.tt = array(NA, c((T+M), N, N))
    P.t = array(NA, c((T+M+1), N, N))
  }else{
    a.tt = matrix(NA, T, N)
    a.t = matrix(NA, (T+1), N)
    P.tt = array(NA, c(T, N, N))
    P.t = array(NA, c((T+1), N, N))
  }#***

  # Start state vector and variance matrix
  a.t[1, ] = mu
  P.t[1, ,] = lyapunov(N = N,phi = phi,Q = Q) 
  logLik = -0.5 * T * ncol(Y) * log(2 * pi)

  Kfilter(logLik = logLik,N = N,T = T,Y = Y,Z = Z,a.t = a.t,P.t = P.t,H = H,a.tt = a.tt,
          P.tt = P.tt,v2 = v2,v1 = v1,phi = phi,mu = mu,Q = Q,prev = prev,M = M,Yf = Yf,lik = lik)
}