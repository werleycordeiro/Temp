Fchol <- function(x){
    out=tryCatch(
        expr = {
			t(chol(x))
        },
        error = function(e){
            #message('Caught an error!')
            print(e)
            return(1e100)
        },
        warning = function(w){
            #message('Caught an warning!')
            print(w)
            return(1e100)
        }#,
        #finally = {
        #    message('All done, quitting.')
        #}
    )
    return(out)
}
