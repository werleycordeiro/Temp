Svensson.factor.loadings = function(para,matu){
 l1 = exp(para[1])
 l2 = exp(para[2])
 A = l1 * matu
 A2 = l2 * matu
 column1 = rep.int(1,length(matu))
 column2 = (1 - exp(-A))/(A)
 column3 = column2 - exp(-A)
 column4 = ((1 - exp(-A2))/(A2)) - exp(-A2)
 lambmat = cbind(column1,column2,column3,column4)
 lambmat
}  
