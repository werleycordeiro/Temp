kalman = function(para,Y,lik,prev,ahead,matu){
  
  source("Svensson.factor.loadings.R")
  source("lyapunov.R")
  source("Kfilter.R")  
  source("Fchol.R")

  M = ahead#***
  # Resize data if Forecast is on.
  if(prev){#***
    T = nrow(Y)
    Yf = Y
    Yf[(T-M+1):T,] = NA
    Y = Y[1:(T-M),]
    T = nrow(Y)
  }else{
    T = nrow(Y)
    Yf = 1
  }#***
  W = ncol(Y)
  N = 4
  # Create vectors and matrices
  #mu = matrix(NA,N,1)
  #phi = diag(N)
  #H = diag(ncol(Y))
  
  # Loading matrix
  Z = Svensson.factor.loadings(para = para,matu = matu)
  # Variance matrix of residuals
  #for(i in 1:17){
  #  H[i,i] = exp(para[i+2])
  #}
  H = diag(para[3:19])
  H = H %*% H
  # Vector autoregressive coeffient matrix: VAR(1)
  phi = matrix(para[20:35],N,N)
  mu = para[36:39]
  Q = matrix(0,N,N)
  Q[lower.tri(Q, diag = TRUE)] = para[40:49]
  Q = Q %*% t(Q)

  #phi[1,1] = para[20]
  #phi[1,2] = para[21]
  #phi[1,3] = para[22]
  #phi[1,4] = para[23]
  #phi[2,1] = para[24]
  #phi[2,2] = para[25]
  #phi[2,3] = para[26]
  #phi[2,4] = para[27]
  #phi[3,1] = para[28]
  #phi[3,2] = para[29]
  #phi[3,3] = para[30]
  #phi[3,4] = para[31]
  #phi[4,1] = para[32]
  #phi[4,2] = para[33]
  #phi[4,3] = para[34]
  #phi[4,4] = para[35]
  # Mean vector
  #mu[1] = para[36]
  #mu[2] = para[37]
  #mu[3] = para[38]
  #mu[4] = para[39]
  # transition covariance matrix of residuals
  #Q[2,1] = para[41]
  #Q[3,1] = para[43]
  #Q[3,2] = para[44]
  #Q[4,1] = para[46]
  #Q[4,2] = para[47]
  #Q[4,3] = para[48]
  #Q = Q + t(Q)
  #Q[1,1] = exp(para[40])
  #Q[2,2] = exp(para[42])
  #Q[3,3] = exp(para[45])
  #Q[4,4] = exp(para[49])
  
  v1 = matrix(NA,T,W)			
  v2 = matrix(NA,T,W)
  # Resize data if Forecast is on.
  if(prev){#***
    a.tt = matrix(NA, (T+M), N)
    a.t = matrix(NA, (T+M+1), N) # if prev=TRUE, always will be dim(a.t)[1]=348
    P.tt = array(NA, c((T+M), N, N))
    P.t = array(NA, c((T+M+1), N, N))
  }else{
    a.tt = matrix(NA, T, N)
    a.t = matrix(NA, (T+1), N)
    P.tt = array(NA, c(T, N, N))
    P.t = array(NA, c((T+1), N, N))
  }#***

  # Start
  a.t[1, ] = mu
  P.t[1, ,] = lyapunov(N = N,phi = phi,Q = Q)
  logLik = - 0.5 * T * ncol(Y) * log(2 * pi)

  # Kalman Filter
  Kfilter(logLik = logLik,N = N,T = T,Y = Y,Z = Z,a.t = a.t,P.t = P.t,H = H,
          a.tt = a.tt,P.tt = P.tt,v2 = v2,v1 = v1,phi = phi,mu = mu,Q = Q,prev = prev,M = M,Yf = Yf,lik = lik)
}