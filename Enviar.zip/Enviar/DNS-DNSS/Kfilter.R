# Filter
Kfilter = function(logLik,N,T,Y,Z,a.t,P.t,H,a.tt,P.tt,v2,v1,phi,mu,Q,prev,M,Yf,lik){
for (t in 1:T){
  v = as.numeric(Y[t, ]) - Z %*% a.t[t, ] 
  F = Z %*% P.t[t, ,] %*% t(Z) + H
  L = Fchol(x = F)
  if(is.matrix(L)){
            u = solve(L) %*% diag(dim(L)[1])
            Xinv = solve(t(L)) %*% u
            logLik = logLik - 0.5 * (log(det(L)*det(L)) + t(v) %*% Xinv %*% v)
    # Updating
    K = P.t[t, , ] %*% t(Z) %*% Xinv
    a.tt[t, ] = a.t[t, ] +  K %*% v
    tmp = diag(N) - K %*% Z # HERE
    P.tt[t, , ] = tmp %*% P.t[t, , ] %*% t(tmp) + K %*% H %*% t(K) # HERE
    #P.tt[t, , ] = P.t[t, , ] - K %*% Z %*% P.t[t, , ]
    v1[t, ] = Z %*% a.tt[t,]
    v2[t, ] = as.numeric(Y[t, ]) - v1[t, ] # Filtered errors
    # Predicting
    a.t[t + 1, ] = phi %*% a.tt[t, ] + (diag(N) - phi) %*% mu  
    P.t[t + 1, ,] = phi %*% P.tt[t, ,] %*% t(phi) + Q
  }else{
    logLik = logLik + 0
  }
  # Forecast
  if(prev){
    if(t > (T - 1))
      for(m in 1:M){
        Yf[t + m,] = Z %*% a.t[t + m, ] 
        a.tt[t + m, ] = a.t[t + m, ]
        P.tt[t + m, , ] = P.t[t + m, , ]
        a.t[t + m + 1, ] = phi %*% a.tt[t + m, ] + (diag(N) - phi) %*% mu  
        P.t[t + m + 1, ,] = phi %*% P.tt[t + m, ,] %*% t(phi) + Q
      }
    }
  }  
  if(lik)
  {
    as.numeric(-logLik)
  }else{
    return(list(a.tt=a.tt,a.t=a.t,P.tt=P.tt,P.t=P.t,v2=v2,v1=v1,Yf=Yf)) #****
  }
}
