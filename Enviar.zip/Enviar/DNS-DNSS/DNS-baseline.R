# author: Werley Cordeiro
# werleycordeiro@gmail.com
# Data
source("dados.R")
# Initial Parameters (See Dynamic-Nelson-Siegel to initial Parameters)  
# Lambda(1x1), H diag matrix (17x17), phi matrix (3x3), mu vector (3x1), Q matrix (3x3). Total: 36 parameters
para = readRDS("otim_DNS.rds")
prev = FALSE # TRUE to Forecast.
ahead = 12 # X-step ahead forecast
lik = FALSE # TRUE to return the value of the loglikelihood function. FALSE to return parameters.
# Kalman Filter function
source("dns-baseline-fun.R")
results = kalman(para = para,Y = data,lik = lik,prev = prev, ahead = ahead,matu = matu)
results

