Nelson.Siegel.factor.loadings = function(l,matu){
 A = l * matu
 column1 = rep.int(1,length(matu))
 column2 = (1 - exp(-A))/(A)
 column3 = column2 - exp(-A)
 lambmat = cbind(column1,column2,column3)
 lambmat
}
