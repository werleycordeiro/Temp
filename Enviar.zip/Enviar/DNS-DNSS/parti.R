part = function(X){
 x1 = round(X/2)
 x11 = x1/2
 x12 = x11

 x2 = X - x1
 x21 = round(x2/2)
 x22 = x2 - x21
 
if(x11%%1==0){x11=x11}else{x11=x11-0.5}
if(x12%%1==0){x12=x12}else{x12=x12+0.5}
 if(x11+x12+x21+x22==X){
	return(list(P1=x11,P2=x12,P3=x21,P4=x22))	
 }else{
 message("falha na partição")
 }
}
# parti = part(X=X_star)
