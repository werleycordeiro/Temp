# README
# Sequência:
# 1.DNS-Macro (somente usar esse...) --> 2.DNS-GARCH-Macro (e somente usar esse...)
# 3.DNS-TVL-Macro --> 4.DNS-GARCH-TVL-Macro

# 1) é definido o booleano "forecast"
# 2) define os dados utilizados em "Dados_Macro.R"
# 3) escolher o modelo para as estimações em duas etapas
# 4) roda os modelos
#frct = c("TRUE","FALSE") 
#frct = select.list(frct,graphics = FALSE, title = "Forecast")
source("dados.R")
W = ncol(data)

models = c("DNS","DNS-GARCH","DNS-TVL","DNS-GARCH-TVL","DNSS","DNSS-GARCH","DNSS-TVL1",
	"DNSS-TVL2","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2")
model = select.list(models,graphics = FALSE)

if(model=="DNS"){
	N = W + 19
}else{
	if(model=="DNS-TVL"){
		N = W + 30
	}else{
		if(model=="DNS-GARCH"){
			N = 2 * W + 21
		}else{
			if(model=="DNS-GARCH-TVL"){
				N = 2 * W + 32
			}else{
				if(model=="DNSS"){
					N = W + 32
				}else{
					if(model=="DNSS-GARCH"){
						N = 2 * W + 34	
					}else{
						if(model=="DNSS-TVL1"||model=="DNSS-TVL2"){
							N = W + 46
						}else{
							if(model=="DNSS-GARCH-TVL1"||model=="DNSS-GARCH-TVL2"){
							N = 2 * W + 48
							}
						}
					}
				}
			}
		}
	}
}
ahead = 12
X = Jan + ahead # Qtd. de obs que entra para previsão; Dentro da função "...-fun.R" são cortadas as últimas aheads;
rol = dim(data)[1] - X + 1 # Qtd. de par iniciais de acordo com as qtds de rolagens que são feitas até fim (menos ahead);
paras = matrix(NA,rol,N)

if(model=="DNS"||model=="DNSS"){
	message(paste0("Jan =", Jan," ", "rol =", rol))
	for(j in 1:rol){

		pb = txtProgressBar(min = (1/rol), max = rol, style = 3)
	   	setTxtProgressBar(pb,j)
	   	data2 = data[j:(Jan+j-1),]
	   	source("DNS-ALL-TS.R")
	   	paras[j,] = para

	}
	 }else{
		if(model=="DNS-GARCH"){ # OK 
		# DNS-GARCH 55 
		paraTMP = readRDS("parass_DNS-TS.rds")
		for(j in 1:rol){

			paras[j,] = c(paraTMP[j,][1:(W + 1)],
						log(((paraTMP[j,][2:(W + 1)]) ^ 2) * 100), # 100 to US and 10 to BR
						paraTMP[j,][(W + 2):length(paraTMP[j,])],
						log(0.40), log(0.40) )
			# lam [1] # H [2:18] # Tau [19:35] # phi [36:44] 3x3 # mu [45:47] # Q [48:53] # gamma [54:55]
		}
	}else{
		if(model=="DNS-TVL"){ # OK 
			# DNS-TVL 47 
			paraTMP = readRDS("parass_DNS-TS.rds")
			for(j in 1:rol){

				paras[j,] = c(paraTMP[j,][2:18], # H para[1:17]
						paraTMP[j,][19:21],0,paraTMP[j,][22:24],0,paraTMP[j,][25:27],0,rep(0,3),0.7, # phi para[]
						paraTMP[j,][28:30],paraTMP[j,][1], # mu para[]
						paraTMP[j,][31:33],0,paraTMP[j,][34:35],0,paraTMP[j,][36],rep(0,2)) # Q para[]
			}

		}else{
			if(model=="DNS-GARCH-TVL"){ # OK 
				# DNS-GARCH-TVL 66
				paraTMP = readRDS("parass_DNS-TS.rds")
				for(j in 1:rol){

				paras[j,] = c(paraTMP[j,][2:18],
						log(((paraTMP[j,][2:18])^2)*100),
						paraTMP[j,][19:21],0,paraTMP[j,][22:24],0,paraTMP[j,][25:27],0,rep(0,3),0.7,
						paraTMP[j,][28:30],paraTMP[j,][1],
						paraTMP[j,][31:33],0,paraTMP[j,][34:35],0,paraTMP[j,][36],rep(0,2),
						log(0.49),log(0.49))
			}

			}else{
					if(model=="DNSS-GARCH"){ # OK 
						# DNSS-GARCH 68 
						paraTMP = readRDS("parass_DNSS-TS.rds")
						for(j in 1:rol){

							paras[j,] = c(paraTMP[j,][1:19],
									log(((paraTMP[j,][3:19])^2)*100),
									paraTMP[j,][20:length(paraTMP[j,])],
									log(0.40),log(0.40))
						# lam [1] lam [2] # H [3:19] # Tau [20:36] # phi [37:52] # mu [53:56] # Q [57:66] # gamma [67:68]

						}

					}else{
						if(model=="DNSS-TVL1"){ # OK 

							paraTMP = readRDS("parass_DNSS-TS.rds")
							for(j in 1:rol){

							paras[j,] = c(paraTMP[j,][2],
									paraTMP[j,][3:19], # H para[]
									paraTMP[j,][20:23],0,paraTMP[j,][24:27],0,paraTMP[j,][28:31],0,paraTMP[j,][32:35],0,rep(0,4),0.5, # phi para[]
									paraTMP[j,][36:39],paraTMP[j,][1], # mu para[]
									paraTMP[j,][40:43],0,paraTMP[j,][44:46],0,paraTMP[j,][47:48],0,paraTMP[j,][49],rep(0,2)) # Q para[]						

							}

							
						}else{
							if(model=="DNSS-TVL2"){ # OK 

								paraTMP = readRDS("parass_DNSS-TS.rds")
								for(j in 1:rol){

									paras[j,] = c(paraTMP[j,][1],
											paraTMP[j,][3:19], # H para[]
											paraTMP[j,][20:23],0,paraTMP[j,][24:27],0,paraTMP[j,][28:31],0,paraTMP[j,][32:35],0,rep(0,4),0.5, # phi para[]
											paraTMP[j,][36:39],paraTMP[j,][2], # mu para[]
											paraTMP[j,][40:43],0,paraTMP[j,][44:46],0,paraTMP[j,][47:48],0,paraTMP[j,][49],rep(0,2)) # Q para[]

								}

							}else{
								if(model=="DNSS-GARCH-TVL1"){ # OK 

									paraTMP = readRDS("parass_DNSS-TS.rds")
									for(j in 1:rol){

										paras[j,] = c(paraTMP[j,][2],
												paraTMP[j,][3:19],
												log(((paraTMP[j,][3:19])^2)*100),
												paraTMP[j,][20:23],0,paraTMP[j,][24:27],0,paraTMP[j,][28:31],0,paraTMP[j,][32:35],0,rep(0,4),0.5,
												paraTMP[j,][36:39],paraTMP[j,][1],
												paraTMP[j,][40:43],0,paraTMP[j,][44:46],0,paraTMP[j,][47:48],0,paraTMP[j,][49],rep(0,2),
												log(0.49),log(0.49))

										}


								}else{
									if(model=="DNSS-GARCH-TVL2"){ # OK 

									paraTMP = readRDS("parass_DNSS-TS.rds")
									for(j in 1:rol){

										paras[j,] = c(paraTMP[j,][1],
										paraTMP[j,][3:19],
										log(((paraTMP[j,][3:19])^2)*100),
										paraTMP[j,][20:23],0,paraTMP[j,][24:27],0,paraTMP[j,][28:31],0,paraTMP[j,][32:35],0,rep(0,4),0.5,
										paraTMP[j,][36:39],paraTMP[j,][2],
										paraTMP[j,][40:43],0,paraTMP[j,][44:46],0,paraTMP[j,][47:48],0,paraTMP[j,][49],rep(0,2),
										log(0.49),log(0.49))							

									}

									}

									}
								}
							}
						}
					}
				}
			}
		}
	}
saveRDS(paras, file = paste0("parass_",model,"-TS.rds"))
