
#--------#
# DNS-TS #
#--------#
# Sequência: 
# 1.DNS-TS --> 2.DNS-GARCH-TS
# 			   3.DNS-TVL-TS
#			   4.DNS-GARCH-TVL-TS

# 5.DNSS-TS --> 6.DNSS-GARCH
#				7.DNSS-TVL1
#				8.DNSS-TVL2
#				9.DNSS-GARCH-TVL1
#				10.DNSS-GARCH-TVL2

#models = c("DNS","DNS-GARCH","DNS-TVL","DNS-GARCH-TVL",
#	"DNSS","DNSS-GARCH","DNSS-TVL1","DNSS-TVL2","DNSS-GARCH-TVL1","DNSS-GARCH-TVL2")
#model = select.list(models,graphics = FALSE)

#---------------#
# Nelson-Siegel # 
#---------------#
if(model=="DNS"){
	suppressMessages(library(YieldCurve)) # Calcular tudo...
	suppressMessages(library(vars))
	results = Nelson.Siegel(rate = data2, maturity = matu) # b1, b2, b3 e lambda estimados
	lam = log(median(results[,4])) # lambda
	covres = sqrt(diag(var(as.numeric(data2) - NSrates(Coeff=results, maturity=matu)))) # H
	#--
	# DNS 36 (OK)
	Wchol = t(chol(summary(VAR(results[,1:3],p=1))$covres)) # Q
	para = as.numeric(
	c(lam, # para[1]
	covres,# para[2:18] 
	Bcoef(VAR(results[,1:3],p=1))[,1:(ncol(results)-1)], # para[19:27]
	colMeans(results[,1:3]), # para[28:30]
	Wchol[lower.tri(Wchol,diag=TRUE)] # para[31:36]
		)
	)
}else{
	if(model=="DNSS"){
					suppressMessages(library(YieldCurve)) # Calcular tudo...
					suppressMessages(library(vars))
					results = Svensson(rate = data2, maturity = matu) # b1, b2, b3, b4, lambda1 e lambda2 estimados
					covres = sqrt(diag(var(as.numeric(data2) - Srates(Coeff=results, maturity=matu, whichRate = "Spot")))) # H
					results = cbind(results[,1],results[,2],results[,3],results[,4],1/results[,5],1/results[,6])
					lam1 = log(median(results[,5])) # lambda1
					lam2 = log(median(results[,6])) # lambda2
					#---
					# DNSS 49 (OK)
					Wchol = t(chol(summary(VAR(results[,1:4],p=1))$covres)) # Q
					para = as.numeric(
					c(lam1, # para[1]
						lam2, # para[2]
						covres,# para[3:19]
						Bcoef(VAR(results[,1:4],p=1))[,1:(ncol(results)-2)], # para[20:35]
						colMeans(results[,1:4]), # para[36:39]
						Wchol[lower.tri(Wchol,diag=TRUE)] # para[40:49]
						)
					)
	}
}
# saveRDS(parass,file=paste0(model,"-TS.rds"))