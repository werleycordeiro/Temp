#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(plotly)
require(xts)

sidebar <- dashboardSidebar(
    sidebarMenu(id = "menu1",
        
        menuItem("Charts", tabName = "Charts", icon = icon("fas fa-chart-bar"), startExpanded = TRUE,
                 menuSubItem("3D View",tabName = "3d_view",icon = icon("fas fa-cubes")),
                 menuSubItem("2D View",tabName = "2d_view",icon = icon("far fa-chart-bar")),
                 menuSubItem("Cross-Section View",tabName = "CS_view",icon = icon("fas fa-chart-line"))
                 ),
        menuItem("Market Expectations", tabName = "expec", icon = icon("fas fa-tags")),
        menuItem("Codes", href = "https://github.com/werleycordeiro/shinyapps",icon = icon("fas fa-code")),
        menuItem("GBcurves Package", href = "https://cran.r-project.org/web/packages/GBcurves/index.html", icon = icon("fas fa-link"))
        
    )
)

body <- dashboardBody(
    
    fluidPage(
        HTML('<meta name="viewport" content="width=1024">'),
        
        tabItems(
            tabItem("3d_view", plotlyOutput("plot", width = "950", height = "500")),
            tabItem("2d_view", plotlyOutput("plot1", width = "950", height = "500")),
            tabItem("CS_view", plotlyOutput("plot2", width = "950", height = "500")),
            tabItem("expec",
                    fluidRow(
                      column(width = 4,
                             selectInput(inputId = "variable", label = "Select a variable:", choices = c("IPCA","Selic"), selected = "IPCA")
                             ),
                      column(width = 4,
                             selectInput(inputId = "year", label = "Select a year:", choices = as.character(c(2002:2021)), selected = "2021")
                             )
                    ),
                    fluidRow(
                        h4("Market Expectations"), plotlyOutput("plot3", width = "960", height = "400")
                    )
            )
        )
    ),
    
    tags$head(
        tags$link(rel = "stylesheet", type = "text/css", href = "custom.css"))
        
)


ui <- dashboardPage(
    
    skin = "purple",
    dashboardHeader(title = "BR Yield Curves"),
    sidebar, # dashboardSidebar
    body # dashboardBody

    ) # ui

server <- function(input, output) {
    # Yields
    yields <- read.csv("https://www.dropbox.com/s/8iyb4vhbljoxfhh/Brazil_Yield_Curves.csv?dl=1", header = TRUE)
    rownames(yields) <- yields[,1]
    yields <- yields[,-c(1,6,7,8,10,11,12,14)]/100
    maturities <- colnames(yields)
    dates <- as.Date(rownames(yields), format="%d-%m-%Y")
    matrix <- t(yields)
    
    #IPCA
    ipca1 <- read.csv("https://www.dropbox.com/s/wm752lt42kmaz5j/IPCA_EXP.csv?dl=1", header = TRUE)
    ipca1 <- data.frame( as.Date(ipca1[,1], format="%Y-%m-%d"), ipca1[,2] )
    colnames(ipca1) <- c("Dates","Rates")
    ipca_obs <- read.csv("https://www.dropbox.com/s/ftoch8td085c9qh/IPCA_Observado.csv?dl=1", header = TRUE, sep=",")
    
    # Selic
    selic1 <- read.csv("https://www.dropbox.com/s/590cfyoysy03nmt/Selic_EXP.csv?dl=1", header = TRUE, sep=",")
    selic1 <- data.frame( as.Date(selic1[,1], format="%m/%d/%Y"), selic1[,2] )
    colnames(selic1) <- c("Dates","Rates")
    selic_obs <- read.csv("https://www.dropbox.com/s/pcoiqda5aao193k/Selic_Observada.csv?dl=1", header = TRUE, sep=",")
    
    # Gráficos
    
    output$plot <- renderPlotly({
        
        # 3D
        colors <- c("#edf4fe","#70bdf2","#315d7e","#243d53")
        
        fig <- plot_ly(x = dates,
                       y = maturities,
                       z = matrix,
                       colorbar=list(
                           title='Rates',
                           ticktext = list("5%", "10%", "15%", "20%"),
                           tickvals = list(.05, .10, .15,.20)
                       ),
                       hovertemplate = paste(
                           "Date: %{x:%d-%m-%Y}<br>",
                           "Maturity: %{y}<br>",
                           "Yield: %{z}<br>",
                           "<extra></extra>"),
                       colors = colors,
                       #width = 1200,
                       #height = 700,
                       contours = list(y = list(show = TRUE, color = "#629abd", highlightcolor = "#ff0000") ),
                       type = "surface"
        )
        
        fig <- fig %>% layout(title = "<b>3D View of Brazil Yield Curves</b>",
                              scene = list(
                                  aspectmode = 'manual',
                                  aspectratio = list(x = 3.75, y = 1.875, z = 1.5),
                                  camera = list(eye = list(x = 3.5, y = -2.88, z = .5)),
                                  xaxis = list(
                                      title = "",
                                      type = 'date',
                                      tickformat = "%Y",
                                      nticks = 17
                                  ),
                                  yaxis = list(
                                      title = "",
                                      tickangle = 10,
                                      ticktext = list("3-month <br> DI rates","6-month", "9-month", "1-year", "2-year", "3-year", "4-year", "5-year", "6-year"),
                                      tickvals = list("M3", "M6", "M9", "M12", "M24", "M36", "M48", "M60", "M72")
                                  ),
                                  zaxis = list(
                                      title = "",
                                      tickformat = "%",
                                      nticks = 5,
                                      side = "right",
                                      ticktext = list("5%", "10%", "15%", "20% yield <br> per year"),
                                      tickvals = list(.05, .10, .15,.20),
                                      tickmode = "array")
                              )
        )
        
        fig <- fig %>% add_trace(x = dates, 
                                 y = maturities[1],
                                 z = matrix[1,],
                                 type="scatter3d",
                                 mode="lines",
                                 line = list(color = "black", width = 4),
                                 name = "3-month <br> DI rates"
        )
        
        fig <- fig %>% add_trace(x = dates,
                                 y = maturities[9],
                                 z = matrix[9,],
                                 type = "scatter3d",
                                 mode = "lines",
                                 line = list(color = "#629abd", width = 4), showlegend = F
        )
        
        fig <- fig %>% add_trace(x = dates[ncol(matrix)],
                                 y = maturities,
                                 z = matrix[,ncol(matrix)],
                                 type = "scatter3d",
                                 mode = "lines",
                                 line = list(color = "orange", width = 4),
                                 name = paste0("Date: ", dates[ncol(matrix)])
        )
        
        options(warn = -1)
        
        fig
        
        }) # final plot
    
    output$plot1 <- renderPlotly({
    
        colors1 <- c("black","#bbdcfc","#B7D9E2","#86B6C6","#5C93AA","#3A728E","#1F5372","#0C3756","darkblue")
        
        rename_maturities <- c("3-month <br> DI rates","6-month", "9-month", "1-year", "2-year", "3-year", "4-year", "5-year", "6-year")
        
        for(i in 1:length(maturities)){
            
            if(i==1){
                
                fig1 <- plot_ly(x = dates,
                                y = yields[,i],
                                type = 'scatter',
                                mode = 'lines',
                                hovertemplate = paste(
                                    "Date: %{x:%d-%m-%Y}<br>",
                                    "Maturity: %{text}<br>",
                                    "Yield: %{y}<br>",
                                    "<extra></extra>"),
                                text = rename_maturities[i],
                                name = rename_maturities[i],
                                line = list( color = colors1[i])
                ) 
                
            }else{
                
                fig1 <- fig1 %>% add_trace(x = dates,
                                           y = yields[,i],
                                           type = 'scatter',
                                           mode = 'lines',
                                           hovertemplate = paste(
                                               "Date: %{x:%d-%m-%Y}<br>",
                                               "Maturity: %{text}<br>",
                                               "Yield: %{y}<br>",
                                               "<extra></extra>"),
                                           hoverinfo = 'x+y+name',
                                           name = rename_maturities[i],
                                           text = rename_maturities[i],
                                           line = list( color = colors1[i] )
                )
                
            }
            
        }
        
        fig1 <- fig1 %>% layout(title = "<b>2D View of Brazil Yield Curves</b>",
                                yaxis = list(
                                    title = "",
                                    tickformat = "%",
                                    nticks = 5,
                                    ticktext = list("5%", "10%", "15%", "20% yield <br> per year"),
                                    tickvals = list(.05, .10, .15, .20),
                                    tickmode = "array"),
                                xaxis = list(
                                    title = "Dates",
                                    rangeslider = list(visible = T))
        )
        
        fig1
        
        }) # final plot1
    
    output$plot2 <- renderPlotly({
        
        
        matrix3 <- xts(yields, order.by = dates)
        matrix3 <- matrix3[xts:::endof(matrix3, "months")]
        rates <- matrix(t(matrix3), prod(dim(matrix3)) , 1)
        mty <- rep(colnames(matrix3),nrow(matrix3))
        
        for(i in 1:nrow(matrix3)){
            
            if(i==1){
                
                dates1 <- rep(index(matrix3)[i],length(colnames(matrix3)))
                
            }else{
                
                dates1.tmp <- rep(index(matrix3)[i],length(colnames(matrix3)))
                dates1 <- c(dates1, dates1.tmp)
                
            }
            
        }
        
        Date <- format(as.Date(dates1,format="%Y-%m"),"%Y-%m")
        
        yields_panel <- data.frame(Date, rates, mty)
        
        fig2 <- yields_panel %>% plot_ly(
            x = ~mty,
            y = ~rates,
            frame = ~Date,
            type = 'scatter',
            mode = 'markers+lines',
            hovertemplate = paste(
                "Date: ", Date,
                "<br>Maturity: %{x}<br>",
                "Yield: %{y}<br>",
                "<extra></extra>"),
            color = "")
        
        fig2 <- fig2 %>% layout(title="<b>Last Day of Month</b>",
            xaxis = list(
                categoryorder = "array",
                categoryarray = ~mty,
                title = "Maturities"
            ),
            yaxis = list(tickformat = ".1%",
                         title = ""
            )
        )
        
        fig2 <- fig2 %>% hide_legend()
        
        fig2 <- fig2 %>% animation_slider(
            currentvalue = list(prefix = "Date: ", font = list(color="black")))
        
        fig2
        
        
    }) # final plot2
    
    output$plot3 <- renderPlotly({
      
      year <- input$year
      variable <- input$variable
      
      
      if(variable=="IPCA"){
        
        mat1 <- ipca1
        df_obs <- ipca_obs
        
      }else{
        
        mat1 <- selic1
        df_obs <- selic_obs
        
      }
      
        df <- mat1[mat1[,1]> paste0(year,"-01-01") & mat1[,1]<= paste0(year,"-12-31"),]
        trace <- df_obs[df_obs[,1]==year,2]
        
        fig3 <- plot_ly(df,
                       y = ~Rates,
                       x = ~Dates,
                       type = "scatter",
                       mode = "lines",
                       hovertemplate = paste("Expectations on<br>",
                                             "Date: %{x:%d-%m-%Y}<br>",
                                             "Rate: %{y}<br>",
                                             "<extra></extra>"),
                       name = paste0(variable," Expectations") 
        )
        
        fig3 <- fig3 %>%
            add_trace(x = df[,"Dates"], y = trace, type = "scatter", mode = "lines", name = paste0(variable," end of year"),
                      hovertemplate = paste(
                          paste0("Date: ",year,"<br>"),
                          "Rate: %{y}<br>")
            )
        fig3
        
          
    }) # final plot3   
    
    }

shinyApp(ui, server)