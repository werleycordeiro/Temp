#=======
#
# Data
#
#=======

library(zoo)

setwd('C:\\Users\\werle\\Dropbox\\paper_werley\\paper_03\\Codes\\PricingTermStructure-master\\dataBRA\\Atualizacao')
# setwd('C:\\Users\\Usuario\\Dropbox\\paper_werley\\paper_03\\Codes\\PricingTermStructure-master\\dataBRA')
# nominal <- readxl::read_excel('dataBRA.xlsx', sheet = "yields_nominal")
# real <- readxl::read_excel('dataBRA.xlsx', sheet = "yields_real")
# datas <- as.matrix(nominal['Date'])
# nominal <- as.data.frame(nominal)[,-1]/100
# real <- as.data.frame(real)[,-1]/100


# Nominal
nominal <- read.csv('Nominal.csv',sep=',',header=T)
datas <- as.Date(nominal[,1],format='%m/%d/%Y')
nominal <- nominal[-1]
rownames(nominal) <- as.character.Date(datas)

# Real
real <- read.csv('Real.csv',sep=',',header=T)
real <- real[,-1]
rownames(real) <- as.character.Date(datas)

# Indice IPCA
Q <- read.csv('Indice_IPCA.csv', sep = ',', header = T)[,2]
pi_lhs <- log( Q[2:length(Q)] / Q[1:(length(Q)-1)] )

#================================================================
#
# Compute log excess returns from continuously compounded yields
#
#================================================================

n_maturities <- 120
ttm <- c(1:n_maturities) / 12
t <- nrow(nominal) - 1  # Number of observations

#---------
# Nominal
#---------

mty_matrix <- matrix(1,nrow(nominal),1) %*% t(as.matrix(ttm))
logPrices <- - nominal *  mty_matrix# P = exp(- i * n) => logP = - i * n
rf <- -logPrices[1:(nrow(logPrices)-1),1] # LogPt+1 - LogPt
rx <- logPrices[2:nrow(logPrices),1:(ncol(logPrices)-1)] - logPrices[1:(nrow(logPrices)-1), 2:ncol(logPrices)] # LogPt+1 - LogPt
rx <- rx - as.matrix(rf) %*% matrix(1,1,119) # Excesso de retorno
rx_maturities <- c(6,  12,  24,  36,  48,  60,  72,  84,  96, 108, 120)
Nn <- length(rx_maturities)
selected_rx <- rx[,(rx_maturities-1)]

#------
# Real
#------

logPrices_R <- - real * mty_matrix 
rx_R <- logPrices_R[2:nrow(logPrices_R),1:(ncol(logPrices_R)-1)] - logPrices_R[1:(nrow(logPrices_R)-1), 2:ncol(logPrices_R)] # LogPt+1 - LogPt
rx_R <- rx_R - as.matrix(rf) %*% matrix(1,1,(ncol(real)-1)) # livre de risco � a M1 nominal # Resultados melhores sem ele em termos de ajuste de lambda
rx_maturities_R <- c(24,  36,  48,  60,  72,  84,  96, 108, 120)
Nr <- length(rx_maturities_R)
selected_rx_R <- rx_R[,(rx_maturities_R-1)]

#===============================
#
# Extract principal components
#
#===============================

Kn <- 3
Kr <- 2

#---------
# Nominal
#---------

scaled_nominal <- apply(nominal[,3:120],2,scale)
pca_nom <- princomp(scaled_nominal)$scores
pca_nom <- apply(pca_nom,2,scale)
pca_nom <- pca_nom[,1:Kn]

#------
# Real
#------

scaled_real <- apply(real[,24:120],2,scale)
res <- lm( scaled_real ~  pca_nom )$residuals
scaled_res <- apply(res,2,scale)
pca_real <- princomp(scaled_res)$scores
pca_real <- apply(pca_real,2,scale)
pca_real <- pca_real[,1:Kr] 


#-----------------#
# Gr�fico fatores #
#-----------------#

legend_Factor <- c("Level ", "Slope ", "Curvature ", "Real Factor 1 ", "Real Factor 2 ")

layout.m <- matrix(
                  c(1,1,2,2,3,3,4,4,0,5,5,0), 
                  nrow=3, byrow=T)   
layout(layout.m)
par(mai = c(0.3, 0.4, 0.4, 0.2))

for(i in 1:5){

  X_plot <- zooreg(X[i,], start = as.yearmon(substr(datas[1],1,7)), freq=12)

  plot(X_plot, type="n",ylim=c(-3,4),xlab="", yaxt="n", xaxt="n", ylab='', lwd=1,xaxs="i", yaxs="i")
  grid(nx = NULL, ny = NULL, lty = 3, col = "gray", lwd = 1)
  lines(X_plot, col='black')
  legend('topright', legend = legend_Factor[i], col = 'black', bg = 'white', lty=1, ncol = 1, cex = 0.8)
  axis(1, floor(time(X_plot)))
  axis(side=2, las=1)
  box()

}


#===========
#
# VAR PCA's
#
#===========


X <- t(cbind(pca_nom, pca_real))
K <- nrow(X)
rownames(X) <- paste0("PCA",c(1:K))
mu_X <- rowMeans(X)

mu_X_mat <- mu_X %*% matrix(1,1,nrow(real))

X <- X - mu_X_mat

X_lhs <- X[,2:ncol(X)] # X
X_rhs <- X[,1:(ncol(X)-1)] # X_

phi <- X_lhs %*% t(X_rhs) %*% solve(X_rhs %*% t(X_rhs)) 

res <- matrix(NA,K,t) # (K x T)

for(i in 1:t){
  
  res[,i] <- X_lhs[,i] - (phi %*% X_rhs[,i])   
  
}

Sigma <- (1/t) * res %*% t(res) # (K x K)

#===================================
#
# Initial Values. See Appendix
#
#===================================

#-------------
# Phi_til_gls
#-------------

selected_rx_R_pi <- selected_rx_R + as.matrix(pi_lhs) %*% matrix(1, 1, ncol(selected_rx_R)) # Lado esquerdo Eq. (23) Appendix
R_pi <- rbind(t(selected_rx),t(selected_rx_R_pi)) #  Stack the observed return data. Vari�veis dependentes Eq. (28) Appendix
Z_ols <- rbind( rep(1,t), X_rhs, X_lhs ) # vari�veis independentes Eq. (28) Appendix

abp <- R_pi %*% t(Z_ols) %*% solve(Z_ols %*% t(Z_ols)) # Estimation Eq. (28) Appendix

alpha_pi_ols <- -abp[,1]
Bphi_til_ols <- -abp[,2:(K+1)]
B_ols <- abp[,(K+2):ncol(abp)]

R_pi_hat <- -alpha_pi_ols %*% t(matrix(1,t,1)) - Bphi_til_ols %*% X_rhs + B_ols %*% X_lhs  

#*********************
# Ponto de checagem 3: sobre o histograma dos res�duos.

vert <- 20
ymax <- max(c(max(R_pi[vert,]),max(R_pi_hat[vert,])))
ymin <- min(c(min(R_pi[vert,]),min(R_pi_hat[vert,])))

plot(R_pi[vert,], ylim = c(ymin, ymax), type = 'l', col = 'blue')
lines(R_pi_hat[vert,], type = 'l', col = 'red', lty=2)
sum((R_pi[vert,] - R_pi_hat[vert,])^2) # Primeiro resultado dos res�duos no v�rtice

# ---- **** Final Checagem **** ----

E_ols <- R_pi - R_pi_hat
Sigma_e <- (1/t) * E_ols %*% t(E_ols)
Sigma_e_inv <- solve(Sigma_e)

phi_til_gls <- solve((t(B_ols) %*% Sigma_e_inv %*% B_ols)) %*% t(B_ols) %*% Sigma_e_inv %*% Bphi_til_ols # Eq. (29) Appendix

#-------------------
# B_gls e alpha_gls
#-------------------

Z_gls <- rbind( rep(1,t), (- phi_til_gls %*% X_rhs + X_lhs) )
ab <- R_pi %*% t(Z_gls) %*% solve(Z_gls %*% t(Z_gls))

alpha_gls <- -ab[,1]
B_gls <- ab[,2:(K+1)]

R_pi_hat_2 <- -alpha_gls %*% matrix(1,1,t) - B_gls %*% phi_til_gls %*% X_rhs + B_gls %*% X_lhs  

#**********************
# Ponto de checagem 4: sobre o histograma dos res�duos. 

vert <- 11
ymax <- max(c(max(R_pi[vert,]),max(R_pi_hat_2[vert,])))
ymin <- min(c(min(R_pi[vert,]),min(R_pi_hat_2[vert,])))

plot(R_pi[vert,], ylim = c(ymin, ymax), type = 'l', col = 'blue')
lines(R_pi_hat_2[vert,], type = 'l', col = 'red', lty=2)
sum((R_pi[vert,] - R_pi_hat[vert,])^2) # Antes 
sum((R_pi[vert,] - R_pi_hat_2[vert,])^2) # Depois

#--------------------------------------------
# gamma_gls e mu_til_gls: Eq. (30) Appendix
#--------------------------------------------

gamma_gls <- rep(NA,nrow(B_gls))

for(i in 1:nrow(B_gls)){
  
  gamma_gls[i] <- t(B_gls[i,]) %*% Sigma %*% t(t(B_gls[i,])) # Eq. (27) Appendix (read line 828 in Appendix)
  
}
gamma_gls <- - gamma_gls

mu_til_gls <- solve( t(B_gls) %*% Sigma_e_inv %*% B_gls ) %*% t(B_gls) %*% Sigma_e_inv %*% as.matrix(alpha_gls + 0.5 * gamma_gls)

#---------
# Lambdas
#---------

lambda_0 <- (diag(K) - phi) %*% mu_X - mu_til_gls
lambda_1 <- phi - phi_til_gls

#--------------
# delta's ols
#--------------

delta_ols <- lm(rf ~ t(X_rhs))$coefficients
delta0_ols <- as.numeric(delta_ols[1])
delta1_ols <- as.numeric(delta_ols[2:(K+1)])

#---------------
# Otimizar pi's
#---------------
'
pi_ols <- lm(pi_lhs ~ t(X_lhs))$coefficients # Pis ols

source("FS.r")
'
#*********************************************************
#
# Ponto de Checagem: Resultados com par�metros iniciais 
# 
# S�o eles: phi_til_gls, mu_til_gls, delta0_ols, delta1_ols, 
#           Sigma, pi_otim_par
#
#
# Al�m disso, tenho B_gls
#
#*********************************************************

#-----------------
# Gr�fico Nominal
#-----------------

Bn <- matrix(0,K,n_maturities)
Bn[,1] <- - delta1_ols
Bn_rn <- matrix(0,K,n_maturities)
Bn_rn[,1] <- - delta1_ols
  
for(i in 2:n_maturities){
  
  Bn[,i] <- Bn[,(i-1)] %*% phi_til_gls - delta1_ols
  Bn_rn[,i] <- Bn_rn[,(i-1)] %*% phi - delta1_ols # Risco-Neutra
  
  
}

An <- rep(0,n_maturities)
An[1] <-  - delta0_ols
An_rn <- rep(0,n_maturities)
An_rn[1] <-  - delta0_ols

for(i in 2:n_maturities){
  
  An[i] <- An[i-1] + Bn[,(i-1)] %*% mu_til_gls + 0.5 * ( Bn[,(i-1)] %*% Sigma %*% Bn[,(i-1)] ) - delta0_ols
  An_rn[i] <- An_rn[i-1] + Bn_rn[,(i-1)] %*% ( diag(K) - phi) %*% mu_X + 0.5 * ( Bn_rn[,(i-1)] %*% Sigma %*% Bn_rn[,(i-1)] ) - delta0_ols  # Risco-Neutra
  
}

fitted <- matrix(NA, ncol(X), n_maturities)
fitted_rn <- matrix(NA, ncol(X), n_maturities)

for(i in 1:ncol(X)){
  
  for(j in 1:n_maturities){
    
      logPrice_rn <- An_rn[j] + Bn_rn[,j] %*% X[,i] # Risco-Neutra
      logPrice <- An[j] + Bn[,j] %*% X[,i]
      fitted_rn[i,j] <- - ( logPrice_rn ) / (ttm)[j] # Risco-Neutra
      fitted[i,j] <- - ( logPrice ) / (ttm)[j]

  }
  
}


#==========================#
# IN�CIO GR�FICOS NOMINAIS #
#==========================#

#---------------------------#
# Nominal Observed x Fitted #
#---------------------------#

mty <- c(12,36,60,120) # At� 120
                         # x  y
par(mfrow=c(2,2), mai = c(0.4, 0.4, 0.4, 0.2))

for(i in 1:4){

  nominal_mty <- nominal[,mty[i]]*100
  fitted_mty <- fitted[,mty[i]]*100

  nominal_mty0 <- zooreg(nominal_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  fitted_mty0 <- zooreg(fitted_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)

  max_lim <- 23
  min_lim <- 0

  #dev.new()
  plot(nominal_mty0, type="n",ylim=c(min_lim,max_lim),xlab="",yaxt="n", xaxt="n",ylab='', lwd=1, xaxs="i", yaxs="i")

  u <- par("usr")
  rect(as.yearmon("2006-1"),u[3],as.yearmon("2011-1"),u[4],border = 0, col = "lightyellow") # Meirelles (2006-1:2010:12)
  rect(as.yearmon("2011-1"),u[3],as.yearmon("2016-6"),u[4],border = 0, col = "lightgreen") # Tombini (2011-1:2016-6)
  rect(as.yearmon("2016-6"),u[3],as.yearmon("2019-2"),u[4],border = 0, col = "lightyellow") # Goldfajn (2016-6:2019-2)
  rect(as.yearmon("2019-2"),u[3],as.yearmon("2023-6"),u[4],border = 0, col = "lightgreen") # Campos Neto (2019-2:2023-6)

  colors <- c('blue','darkgreen','black','red')

  #abline(v=as.yearmon("2016-4"), lty = 3, col = "black", lwd = 1)
  abline(h=3, lty = 3, col = "gray", lwd = 1)
  abline(h=9, lty = 3, col = "gray", lwd = 1)
  abline(h=15, lty = 3, col = "gray", lwd = 1)
  #grid(nx = NULL, ny = NULL, lty = 2, col = "gray", lwd = 1)

  lines(nominal_mty0, col=colors[1])
  lines(fitted_mty0, col=colors[2], lty=5)

  axis(1, floor(time(nominal_mty0)))

  ytick<-seq(min_lim, max_lim, by=3)
  axis(side=2, las=1, at=ytick)

  legend('bottomleft', legend=c(paste0(mty[i]/12,"Y"," Observed Nominal Yield "), 
                                paste0(mty[i]/12,"Y"," Fitted Nominal Yield ")),
         col=colors,bg='white',ncol=1, lty=c(1,5), cex=0.8)

  #YY <- max(nominal_mty0) + 2

  text(as.yearmon("2008-6"), 21, "Meirelles")
  text(as.yearmon("2013-9"), 21, "Tombini")
  text(as.yearmon("2017-10"),21, "Goldfajn")
  text(as.yearmon("2021-4"), 21, "Campos Neto")
  box()

}

#----------------------#
# Nominal Term Premium #
#----------------------#

mty <- c(12,36,60,120) # At� 120
                         # x  y
par(mfrow=c(2,2), mai = c(0.4, 0.4, 0.4, 0.2))

for(i in 1:4){

  nominal_mty <- nominal[,mty[i]]*100
  fitted_rn_mty <- fitted_rn[,mty[i]]*100
  nominal_TP_mty <- nominal_mty - fitted_rn_mty

  nominal_mty0 <- zooreg(nominal_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  fitted_rn_mty0 <- zooreg(fitted_rn_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  nominal_TP_mty0 <- zooreg(nominal_TP_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)

  max_lim <- 23
  min_lim <- -6

  #dev.new()
  plot(nominal_mty0, type="n",ylim=c(min_lim,max_lim),xlab="",xaxt="n",yaxt="n",ylab='', lwd=1,xaxs="i", yaxs="i")

  u <- par("usr")
  rect(as.yearmon("2006-1"),u[3],as.yearmon("2011-1"),u[4],border = 0, col = "lightyellow") # Meirelles (2006-1:2010:12)
  rect(as.yearmon("2011-1"),u[3],as.yearmon("2016-6"),u[4],border = 0, col = "lightgreen") # Tombini (2011-1:2016-6)
  rect(as.yearmon("2016-6"),u[3],as.yearmon("2019-2"),u[4],border = 0, col = "lightyellow") # Goldfajn (2016-6:2019-2)
  rect(as.yearmon("2019-2"),u[3],as.yearmon("2023-6"),u[4],border = 0, col = "lightgreen") # Campos Neto (2019-2:2023-6)

  abline(h=-3, lty = 3, col = "gray", lwd = 1)
  abline(h=3, lty = 3, col = "gray", lwd = 1)
  abline(h=9, lty = 3, col = "gray", lwd = 1)
  abline(h=15, lty = 3, col = "gray", lwd = 1)
  abline(h=0, lty=2)
  # grid(nx = NULL, ny = NULL, lty = 2, col = "gray", lwd = 1)

  lines(nominal_mty0, col=colors[1], lty=1)
  lines(fitted_rn_mty0, col=colors[3], lty=6)
  lines(nominal_TP_mty0, col=colors[4], lty=2)

  ytick<-seq(min_lim, max_lim, by=3)
  axis(side=2, las=1, at=ytick)

  axis(1, floor(time(nominal_mty0)))

  legend('bottomleft', legend=c(paste0(mty[i]/12,"Y"," Observed Nominal Yield "),
                              paste0(mty[i]/12,"Y"," Risk Neutral Nominal Yield "),
                              paste0(mty[i]/12,"Y"," Nominal Term Premium ")),
         col=c(colors[1],colors[3],colors[4]),bg='white',ncol=2, lty=c(1,6,2), cex=0.8)

  text(as.yearmon("2008-6"), 21, "Meirelles")
  text(as.yearmon("2013-9"), 21, "Tombini")
  text(as.yearmon("2017-10"),21, "Goldfajn")
  text(as.yearmon("2021-4"), 21, "Campos Neto")
  box()
}

#----x FINAL GR�FICOS NOMINAIS x----



#--------------
# Otimizar Real
#--------------

otim_real <- function(pis){

  pi0 <- pis[1]
  pi1 <- pis[2:(K+1)]
    
  Bn_R <- matrix(0,K,n_maturities)
  Bn_R[,1] <- pi1 %*% phi_til_gls - delta1_ols
  Bn_rn_R <- matrix(0,K,n_maturities)
  Bn_rn_R[,1] <- pi1 %*% phi - delta1_ols
  
  for(i in 2:n_maturities){
    
    Bn_R[,i] <- (Bn_R[,(i-1)] + pi1) %*% phi_til_gls - delta1_ols
    Bn_rn_R[,i] <- (Bn_rn_R[,(i-1)] + pi1) %*% phi - delta1_ols # Risco-Neutra
    
    
  }
  
  delta0_R <- delta0_ols - pi0
  
  An_R <- rep(0,n_maturities)
  An_R[1] <-  pi1 %*% mu_til_gls + 0.5 * (pi1 %*% Sigma %*% pi1) - delta0_R
  An_rn_R <- rep(0,n_maturities)
  An_rn_R[1] <-  pi1 %*% (diag(K) - phi) %*% mu_X + 0.5 * (pi1 %*% Sigma %*% pi1) - delta0_R
  
  for(i in 2:n_maturities){
    
    An_R[i] <- An_R[i-1] + (Bn_R[,(i-1)] + pi1) %*% mu_til_gls + 0.5 * ( (Bn_R[,(i-1)] + pi1) %*% Sigma %*% (Bn_R[,(i-1)] + pi1) ) - delta0_R
    An_rn_R[i] <- An_rn_R[i-1] + (Bn_rn_R[,(i-1)] + pi1) %*% ( diag(K) - phi) %*% mu_X + 0.5 * ( (Bn_rn_R[,(i-1)] + pi1) %*% Sigma %*% (Bn_rn_R[,(i-1)] + pi1)) - delta0_R  # Risco-Neutra
    
  }
  
  fitted_R <- matrix(NA, ncol(X), n_maturities)
  fitted_rn_R <- matrix(NA, ncol(X), n_maturities)
  
  for(i in 1:ncol(X)){
    
    for(j in 1:n_maturities){
      
      logPrice_rn_R <- An_rn_R[j] + Bn_rn_R[,j] %*% X[,i] # Risco-Neutra
      logPrice_R <- An_R[j] + Bn_R[,j] %*% X[,i]
      fitted_rn_R[i,j] <- - ( logPrice_rn_R ) / (ttm)[j] # Risco-Neutra
      fitted_R[i,j] <- - ( logPrice_R ) / (ttm)[j]
      
    }
    
  }
  
  erro <- (real[,c(12,rx_maturities_R)] - fitted_R[,c(12,rx_maturities_R)])^2
  erro <- sum(erro)
  return(erro)
  
}

# 0.01357689

pis <- as.numeric(lm(pi_lhs ~ t(X_lhs))$coefficients)

otim_real(pis)

otim <- optim(par = pis, fn = otim_real, method = c("Nelder-Mead"),control = list(trace=6,maxit=1500000))

otim_real(otim$par)

otim2 <- nlminb(start = otim$par, objective = otim_real, control = list(trace=1))

otim_real(otim2$par)


######

pi0 <- otim2$par[1]
pi1 <- otim2$par[2:(K+1)]

Bn_R <- matrix(0,K,n_maturities)
Bn_R[,1] <- pi1 %*% phi_til_gls - delta1_ols
Bn_rn_R <- matrix(0,K,n_maturities)
Bn_rn_R[,1] <- pi1 %*% phi - delta1_ols

for(i in 2:n_maturities){
  
  Bn_R[,i] <- (Bn_R[,(i-1)] + pi1) %*% phi_til_gls - delta1_ols
  Bn_rn_R[,i] <- (Bn_rn_R[,(i-1)] + pi1) %*% phi - delta1_ols # Risco-Neutra
  
  
}

delta0_R <- delta0_ols - pi0

An_R <- rep(0,n_maturities)
An_R[1] <-  pi1 %*% mu_til_gls + 0.5 * (pi1 %*% Sigma %*% pi1) - delta0_R
An_rn_R <- rep(0,n_maturities)
An_rn_R[1] <-  pi1 %*% (diag(K) - phi) %*% mu_X + 0.5 * (pi1 %*% Sigma %*% pi1) - delta0_R

for(i in 2:n_maturities){
  
  An_R[i] <- An_R[i-1] + (Bn_R[,(i-1)] + pi1) %*% mu_til_gls + 0.5 * ( (Bn_R[,(i-1)] + pi1) %*% Sigma %*% (Bn_R[,(i-1)] + pi1) ) - delta0_R
  An_rn_R[i] <- An_rn_R[i-1] + (Bn_rn_R[,(i-1)] + pi1) %*% ( diag(K) - phi) %*% mu_X + 0.5 * ( (Bn_rn_R[,(i-1)] + pi1) %*% Sigma %*% (Bn_rn_R[,(i-1)] + pi1)) - delta0_R  # Risco-Neutra
  
}

fitted_R <- matrix(NA, ncol(X), n_maturities)
fitted_rn_R <- matrix(NA, ncol(X), n_maturities)

for(i in 1:ncol(X)){
  
  for(j in 1:n_maturities){
    
    logPrice_rn_R <- An_rn_R[j] + Bn_rn_R[,j] %*% X[,i] # Risco-Neutra
    logPrice_R <- An_R[j] + Bn_R[,j] %*% X[,i]
    fitted_rn_R[i,j] <- - ( logPrice_rn_R ) / (ttm)[j] # Risco-Neutra
    fitted_R[i,j] <- - ( logPrice_R ) / (ttm)[j]
    
  }
  
}

# library(zoo)

#------------------------#
# Real Observed x Fitted #
#------------------------#

mty <- c(12,36,60,120) # At� 120
                         # x  y
par(mfrow=c(2,2), mai = c(0.4, 0.4, 0.4, 0.2))

max_lim_R <- 14
min_lim_R <- -3

for(i in 1:4){

  real_mty <- real[,mty[i]]*100
  fitted_R_mty <- fitted_R[,mty[i]]*100

  real_mty0 <- zooreg(real_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  fitted_R_mty0 <- zooreg(fitted_R_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)

  plot(real_mty0, type="n",ylim=c(min_lim_R,max_lim_R),xlab="",xaxt="n",yaxt="n",ylab='', lwd=1, xaxs="i", yaxs="i")

  u <- par("usr")
  rect(as.yearmon("2006-1"),u[3],as.yearmon("2011-1"),u[4],border = 0, col = "lightyellow") # Meirelles (2006-1:2010:12)
  rect(as.yearmon("2011-1"),u[3],as.yearmon("2016-6"),u[4],border = 0, col = "lightgreen") # Tombini (2011-1:2016-6)
  rect(as.yearmon("2016-6"),u[3],as.yearmon("2019-2"),u[4],border = 0, col = "lightyellow") # Goldfajn (2016-6:2019-2)
  rect(as.yearmon("2019-2"),u[3],as.yearmon("2023-6"),u[4],border = 0, col = "lightgreen") # Campos Neto (2019-2:2023-6)

  colors <- c('blue','darkgreen','black','red')

  abline(h=3, lty = 3, col = "gray", lwd = 1)
  abline(h=9, lty = 3, col = "gray", lwd = 1)
  abline(h=0, lty=2)

  #grid(nx = NULL, ny = NULL, lty = 2, col = "gray", lwd = 1)

  lines(real_mty0, col=colors[1])
  lines(fitted_R_mty0, col=colors[2], lty=5)

  ytick<-seq(min_lim, max_lim, by=3)
  axis(side=2, las=1, at=ytick)

  axis(1, floor(time(real_mty0)))

  legend('bottomleft', legend=c(paste0(mty[i]/12,"Y Observed Real Yield "),
                              paste0(mty[i]/12,"Y Fitted Real Yield ")),
         col=colors,bg='white',ncol=1, lty=c(1,5), cex=0.8)

  text(as.yearmon("2008-6"), 12, "Meirelles")
  text(as.yearmon("2013-9"), 12, "Tombini")
  text(as.yearmon("2017-10"),12, "Goldfajn")
  text(as.yearmon("2021-4"), 12, "Campos Neto")
  box()

}

#-------------------#
# Real Term Premium #
#-------------------#

max_lim_R <- 14
min_lim_R <- -5

mty <- c(12,36,60,120) # At� 120
                         # x  y
par(mfrow=c(2,2), mai = c(0.4, 0.4, 0.4, 0.2))

for(i in 1:4){

  real_mty <- real[,mty[i]]*100
  fitted_rn_R_mty <- fitted_rn_R[,mty[i]]*100
  real_TP_mty <- real_mty - fitted_rn_R_mty

  real_mty0 <- zooreg(real_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  fitted_rn_R_mty0 <- zooreg(fitted_rn_R_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  real_TP_mty0 <- zooreg(real_TP_mty, start = as.yearmon(substr(datas[1],1,7)), freq=12)

  plot(real_mty0, type="n",ylim=c(min_lim_R,max_lim_R),xlab="",xaxt="n",yaxt="n",ylab='', lwd=1,xaxs="i", yaxs="i")

  u <- par("usr")
  rect(as.yearmon("2006-1"),u[3],as.yearmon("2011-1"),u[4],border = 0, col = "lightyellow") # Meirelles (2006-1:2010:12)
  rect(as.yearmon("2011-1"),u[3],as.yearmon("2016-6"),u[4],border = 0, col = "lightgreen") # Tombini (2011-1:2016-6)
  rect(as.yearmon("2016-6"),u[3],as.yearmon("2019-2"),u[4],border = 0, col = "lightyellow") # Goldfajn (2016-6:2019-2)
  rect(as.yearmon("2019-2"),u[3],as.yearmon("2023-6"),u[4],border = 0, col = "lightgreen") # Campos Neto (2019-2:2023-6)

  abline(h=-3, lty = 3, col = "gray", lwd = 1)
  abline(h=3, lty = 3, col = "gray", lwd = 1)
  abline(h=9, lty = 3, col = "gray", lwd = 1)
  abline(h=0, lty=2)
  #grid(nx = NULL, ny = NULL, lty = 2, col = "gray", lwd = 1)

  lines(real_mty0, col=colors[1], lty=1)
  lines(fitted_rn_R_mty0, col=colors[3], lty=6)
  lines(real_TP_mty0, col=colors[4], lty=2)

  ytick<-seq(min_lim, max_lim, by=3)
  axis(side=2, las=1, at=ytick)

  axis(1, floor(time(real_mty0)))

  legend('bottomleft', legend=c(paste0(mty[i]/12,"Y Observed Real Yield "),
                              paste0(mty[i]/12,"Y Risk Neutral Real Yield "),
                              paste0(mty[i]/12,"Y Real Term Premium ")),
         col=c(colors[1],colors[3],colors[4]),bg='white',ncol=2, lty=c(1,6,2), cex=0.8)

  text(as.yearmon("2008-6"), 12, "Meirelles")
  text(as.yearmon("2013-9"), 12, "Tombini")
  text(as.yearmon("2017-10"),12, "Goldfajn")
  text(as.yearmon("2021-4"), 12, "Campos Neto")
  box()

}

#--------------------------#
#   Inflation Break-even   #
#--------------------------#

mty <- 120

max_lim <- 14
min_lim <- -6

mty <- c(12,36,60,120) # At� 120
                         # x  y
par(mfrow=c(2,2), mai = c(0.4, 0.4, 0.4, 0.2))

for(i in 1:4){

  BreakEv <- (nominal[,mty[i]] - real[,mty[i]])*100 # Diferen�a entre a curva nominal e real
  ExpInf <- (fitted_rn[,mty[i]] - fitted_rn_R[,mty[i]])*100 # Diferen�a a risco-ajustada nominal e risco-ajustada real
  InfRiskPr <- BreakEv - ExpInf

  colors <- c('blue','red','darkgreen')

  BreakEv0 <- zooreg(BreakEv, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  InfRiskPr0 <- zooreg(InfRiskPr, start = as.yearmon(substr(datas[1],1,7)), freq=12)
  ExpInf0 <- zooreg(ExpInf, start = as.yearmon(substr(datas[1],1,7)), freq=12)


  plot(BreakEv0, type="n",ylim=c(min_lim,max_lim),xlab="",xaxt="n",yaxt="n",ylab='', lwd=1,xaxs="i", yaxs="i")

  u <- par("usr")
  rect(as.yearmon("2006-1"),u[3],as.yearmon("2011-1"),u[4],border = 0, col = "lightyellow") # Meirelles (2006-1:2010:12)
  rect(as.yearmon("2011-1"),u[3],as.yearmon("2016-6"),u[4],border = 0, col = "lightgreen") # Tombini (2011-1:2016-6)
  rect(as.yearmon("2016-6"),u[3],as.yearmon("2019-2"),u[4],border = 0, col = "lightyellow") # Goldfajn (2016-6:2019-2)
  rect(as.yearmon("2019-2"),u[3],as.yearmon("2023-6"),u[4],border = 0, col = "lightgreen") # Campos Neto (2019-2:2023-6)

  abline(h=-3, lty = 3, col = "gray", lwd = 1)
  abline(h=3, lty = 3, col = "gray", lwd = 1)
  abline(h=9, lty = 3, col = "gray", lwd = 1)
  abline(h=0, lty=2)
  #grid(nx = NULL, ny = NULL, lty = 2, col = "gray", lwd = 1)

  lines(BreakEv0, col=colors[1])
  lines(InfRiskPr0, col=colors[2], lty=5)
  lines(ExpInf0, col=colors[3], lty=6)

  ytick<-seq(min_lim, max_lim, by=3)
  axis(side=2, las=1, at=ytick)

  axis(1, floor(time(BreakEv0)))

  legend('bottomleft', legend=c(paste0(mty[i]/12,"Y Breakeven "),
                              paste0(mty[i]/12,"Y Inflation Risk Premium "),
                              paste0(mty[i]/12,"Y Expected Inflation ")),
         col=colors,bg='white',ncol=2, lty=c(1,5,6), cex=0.8)

   text(as.yearmon("2008-6"), 12, "Meirelles")
    text(as.yearmon("2013-9"), 12, "Tombini")
    text(as.yearmon("2017-10"),12, "Goldfajn")
    text(as.yearmon("2021-4"), 12, "Campos Neto")
  box()
}


#------------------------------------#
#  Mountains Inflation Risk Premium  #
#------------------------------------#
library(ggplot2)


BreakEv <- (nominal - real) * 100 # Diferen�a entre a curva nominal e real
ExpInf <- (fitted_rn - fitted_rn_R) * 100 # Diferen�a a risco-ajustada nominal e risco-ajustada real
InfRiskPr <- BreakEv - ExpInf

Year <- as.integer(format(as.Date(rownames(InfRiskPr)), "%Y"))
InfRiskPr <- data.frame(Year,InfRiskPr)

mat_yields <- matrix(NA,length(unique(Year)),(ncol(InfRiskPr)-1))

years <- unique(Year)

for(i in 1:length(years)){

  agregar <- InfRiskPr[InfRiskPr$Year==years[i],]
  agregar <- apply(agregar,2,mean)
  mat_yields[i,] <- as.numeric(agregar[2:121])

}

mat_yields_s <- mat_yields[,c(6,12,18,24,30,36,48,60,72,84,96,120)]
mat_yields_s <- t(mat_yields_s)

colnames(mat_yields_s) <- unique(Year)
maturities <- c('M6','M12','M18','M24','M30','M36','M48','M60','M72','M84','M96','M120')
rownames(mat_yields_s) <- maturities

for(i in 1:length(maturities)){


  if(i==1){

    tmp <- mat_yields_s[i,]
    tmp0 <- cbind(rep(maturities[i], length(tmp)), tmp)   

  }else{

    tmp1 <- cbind(rep(maturities[i], length(tmp)), mat_yields_s[i,])
    tmp0 <- rbind(tmp0, tmp1)

  }

}

tmp0 <- data.frame(tmp0[,1],as.numeric(tmp0[,2]))
colnames(tmp0) <- c("Maturities","Inflation Riks Premium")
tmp0 <- dplyr::as_tibble(tmp0)


gghistmap <- ggplot(tmp0, aes(x = `Inflation Riks Premium`, y = `Maturities`, fill = ..x..)) +
  geom_density_ridges_gradient(scale = 3, rel_min_height = 0.01) +
  scale_fill_viridis(option = "H", direction = -1)+
  scale_y_discrete(limits = maturities) +
  labs(title = 'Average Annual Inflation Risk Premium from 2006 to 2023') +
  theme(axis.title.y = element_text(size=40, vjust=0.5)) +
  theme(axis.title.x = element_text(size=40, vjust=-0.5)) +
  theme_ipsum() +
    theme(
      legend.position="none",
      panel.spacing = unit(0.1, "lines"),
      strip.text.x = element_text(size = 8)
    )
gghistmap


#---------------------------------#
# BoxPlot Inflation Risk Premium  #
#---------------------------------#
col.pal<-colorRampPalette(c("#edf4fe","#70bdf2","#315d7e"))
colors<-col.pal(12)

#colors<-rev(colors)
# title="Average Annual Inflation Risk Premium from 2006 to 2023",
# Use single color
p <- ggplot(tmp0, aes(x=`Maturities`, y=`Inflation Riks Premium`, fill=`Maturities`)) +
      geom_boxplot(fill=colors, color="black") +
      scale_y_continuous(breaks = round(seq(-2, 2, by = 0.5),1)) +
      scale_x_discrete(limits = maturities) +
      scale_fill_brewer(palette="Blues") +
      theme_classic() +
      labs(x="Maturities", y = "Rates") +
      geom_hline(yintercept = 1.5,linetype = "dotted", color="gray") +
      geom_hline(yintercept = 1,linetype = "dotted", color="gray") +
      geom_hline(yintercept = .5,linetype = "dotted", color="gray") +
      geom_hline(yintercept = 0,linetype = "dotted", color="gray") +
      geom_hline(yintercept = -.5,linetype = "dotted", color="gray") +
      geom_hline(yintercept = -1,linetype = "dotted", color="gray") +
      geom_hline(yintercept = -1.5,linetype = "dotted", color="gray") 

p

